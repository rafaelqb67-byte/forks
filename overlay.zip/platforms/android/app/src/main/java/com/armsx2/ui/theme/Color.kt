package com.armsx2.ui.theme

import androidx.compose.ui.graphics.Color

val ArmsBlue = Color(0xFFF59E0B)
val ArmsBlueBright = Color(0xFFFFB84D)
val ArmsCyan = Color(0xFF2DD4A7)
val ArmsViolet = Color(0xFFFF7A59)

// Night palette leans on the OG ARMSX2 blue — a deep navy rather than near-black —
// so the backdrop scrim, cards, toolbar and search field all read blue (matching
// vivi's mockups). Kept dark/desaturated so covers still pop; tune the ramp here.
val NightBackground = Color(0xFF141210)
val NightSurface = Color(0xFF1E1B18)
val NightSurfaceRaised = Color(0xFF2A2622)
val NightOutline = Color(0xFF4A423A)
val NightText = Color(0xFFFBF6EE)
val NightTextMuted = Color(0xFFB3A99C)

val DayBackground = Color(0xFFFAF6F0)
val DaySurface = Color(0xFFFFFFFF)
val DaySurfaceRaised = Color(0xFFF1EADF)
val DayOutline = Color(0xFFDACFC0)
val DayText = Color(0xFF1C1712)
val DayTextMuted = Color(0xFF6F6355)

val Success = Color(0xFF51D79A)
val Warning = Color(0xFFFFC857)
val Danger = Color(0xFFFF6B7A)

