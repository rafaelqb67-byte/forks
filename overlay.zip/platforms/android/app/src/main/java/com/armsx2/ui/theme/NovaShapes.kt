package com.armsx2.ui.theme

import androidx.compose.foundation.shape.CornerSize
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

// NovaSX2: todo o app usava cantos arredondados. Aqui os cantos viram chanfros assimétricos
// (dois cantos opostos cortados em diagonal, os outros quase retos). As chamadas antigas a
// RoundedCornerShape(...) apontam para estas funções, então o formato se ajusta em um lugar só.
private fun cut(v: Dp): Dp = (v.value * 0.7f).coerceAtMost(16f).dp
private fun small(v: Dp): Dp = (cut(v).value * 0.25f).dp

fun RoundedCornerShape(size: Dp): CutCornerShape =
    CutCornerShape(topStart = cut(size), topEnd = small(size), bottomEnd = cut(size), bottomStart = small(size))

fun RoundedCornerShape(percent: Int): CutCornerShape =
    CutCornerShape(
        topStart = CornerSize(percent),
        topEnd = CornerSize(percent / 4),
        bottomEnd = CornerSize(percent),
        bottomStart = CornerSize(percent / 4),
    )

fun RoundedCornerShape(
    topStart: Dp = 0.dp,
    topEnd: Dp = 0.dp,
    bottomEnd: Dp = 0.dp,
    bottomStart: Dp = 0.dp,
): CutCornerShape = CutCornerShape(
    topStart = cut(topStart), topEnd = cut(topEnd), bottomEnd = cut(bottomEnd), bottomStart = cut(bottomStart),
)
