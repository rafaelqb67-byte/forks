package com.armsx2.ui.emulation

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.EaseIn
import androidx.compose.animation.core.EaseOut
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.shape.CircleShape
import com.armsx2.ui.theme.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.layout
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.armsx2.i18n.str
import com.armsx2.runtime.MainActivityRuntime
import com.armsx2.ui.InGameOverlay
import com.armsx2.ui.achievements.AchievementItem
import com.armsx2.ui.common.GameCoverArt
import com.armsx2.ui.settings.controllerFocusable
import com.armsx2.ui.settings.overrideMarker
import com.armsx2.ui.touch.TouchControls
import com.armsx2.ui.theme.Danger
import com.armsx2.ui.common.StatusChip
import com.armsx2.ui.theme.Success
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/** The Friends panel's nav layer: only its controls answer the pad while it is open. */
private const val FRIENDS_NAV_LAYER = "menu.friends"

@Composable
fun EmulationMenuScreen(viewModel: EmulationMenuViewModel = viewModel()) {
    val state = viewModel.state.value
    val scope = rememberCoroutineScope()
    var shown by remember { mutableStateOf(false) }
    var dismissing by remember { mutableStateOf(false) }
    var friendsOpen by remember { mutableStateOf(false) }
    // A friend waiting to be let in is answered in the hosting panel, which sits with Friends: the
    // menu opens there, whether it was opened for the question or was already open.
    val hostStatus by com.armsx2.remoteplay.RemotePlayHost.status
    val asking = hostStatus is com.armsx2.remoteplay.RemotePlayHost.Status.Asking
    LaunchedEffect(asking) { if (asking) friendsOpen = true }
    val closeMenu: () -> Unit = remember(viewModel, scope) {
        {
            if (!dismissing) {
                dismissing = true
                shown = false
                // ★ Dispatchers.Main, NOT the composition's own dispatcher. rememberCoroutineScope
                // inherits the composition context, which on Android is AndroidUiDispatcher — it
                // dispatches continuations on CHOREOGRAPHER FRAME CALLBACKS. We have just set
                // shown = false, so once the exit animation settles Compose has nothing left to
                // invalidate, no frame is scheduled, and the continuation after this delay is
                // never dispatched: the VM is simply never told to resume. The game sits paused
                // with the OSD reading "FPS: N/A" until something incidentally causes a frame —
                // which is exactly why tapping the on-screen controls "speeds up" the recovery
                // (touch input schedules a frame) and why waiting also eventually works.
                // Dispatchers.Main is a plain main-looper Handler dispatcher with no frame
                // dependency, so the resume fires on time whether or not anything is drawing.
                scope.launch(Dispatchers.Main) {
                    delay(220)
                    viewModel.dismissHandler = null
                    viewModel.resumeImmediately()
                }
            }
        }
    }

    DisposableEffect(viewModel, closeMenu) {
        viewModel.dismissHandler = closeMenu
        EmulationMenuInputController.bind(viewModel)
        onDispose {
            viewModel.dismissHandler = null
            EmulationMenuInputController.unbind(viewModel)
        }
    }
    LaunchedEffect(Unit) { shown = true }

    // Hand pad input to the Friends panel while it is open, and give it back on close.
    //
    // The nav registry is shared between the menu and the panel, so ownership has to be explicit:
    // the selection is cleared on both edges, because a selection left pointing at a control on
    // the other side of the transition highlights something the user cannot see.
    // The panel claims its own nav layer while open: the menu stays composed behind it, and without
    // a layer a move could pick one of the menu's controls. Closing hands the selection back to
    // the menu control that opened it.
    DisposableEffect(friendsOpen) {
        if (!friendsOpen) return@DisposableEffect onDispose {}
        EmulationMenuInputController.overlayDismiss = { friendsOpen = false }
        com.armsx2.ui.settings.SettingsControllerNav.pushLayer(FRIENDS_NAV_LAYER)
        onDispose {
            EmulationMenuInputController.overlayDismiss = null
            com.armsx2.ui.settings.SettingsControllerNav.popLayer(FRIENDS_NAV_LAYER)
        }
    }
    // Highlight the panel's first control once it has actually composed. Selecting in the same
    // frame the panel opens would find an empty registry — controllerFocusable only registers
    // items that exist, and the panel's do not until AnimatedVisibility has run.
    LaunchedEffect(friendsOpen) {
        if (friendsOpen) {
            delay(260)
            if (friendsOpen) com.armsx2.ui.settings.SettingsControllerNav.selectFirstInLayer()
        }
    }
    // Back closes the friends overlay first when it is up. Without this, opening Friends and
    // pressing Back would dismiss the entire pause menu and resume the game, which is not what
    // anyone means by "go back" from a panel sitting on top of another panel.
    BackHandler(onBack = { if (friendsOpen) friendsOpen = false else closeMenu() })

    state.pendingHardcore?.let { enabling ->
        androidx.compose.runtime.DisposableEffect(Unit) {
            com.armsx2.MenuSfx.play(com.armsx2.MenuSfx.Event.POPUP_OPEN)
            onDispose { com.armsx2.MenuSfx.play(com.armsx2.MenuSfx.Event.POPUP_CLOSE) }
        }
        // Was an AlertDialog, which is its own focused Android window and so consumed the pad
        // before the Activity dispatcher that owns every D-pad route in this app could see it.
        // The prompt sat on top of the pause menu, which IS pad-navigable, so it read as the
        // controller having gone dead the moment the confirmation appeared.
        com.armsx2.ui.common.ConfirmOverlay(
            title = str(if (enabling) "ra.hardcore.enable.title" else "ra.hardcore.disable.title"),
            message = str(if (enabling) "ra.hardcore.enable.body" else "ra.hardcore.disable.body"),
            confirmLabel = str(if (enabling) "ra.hardcore.enable.confirm" else "ra.hardcore.disable.confirm"),
            idPrefix = "hardcore",
            onConfirm = viewModel::confirmToggleHardcore,
            onDismiss = viewModel::cancelToggleHardcore,
        )
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val compact = maxWidth < 700.dp
        // The one place the layout is chosen is the one place that tells the pad which way it
        // runs — compact puts the tabs in a Row above the content, wide puts them in a rail to
        // its right, and the D-pad axis follows from here rather than from a constant that can
        // fall out of step with the UI (which is exactly what it had done).
        androidx.compose.runtime.SideEffect {
            EmulationMenuInputController.tabsHorizontal.value = compact
        }
        AnimatedVisibility(
            visible = shown,
            enter = fadeIn(tween(190, easing = EaseOut)),
            exit = fadeOut(tween(190, easing = EaseIn)),
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.62f))
                    .clickable(onClick = closeMenu),
            )
        }
        // Right edge by default, left when the user asks for it. Everything that encodes
        // "which side" moves together — dock alignment, slide direction, which corners are
        // rounded, and which edge gets the inset — because a half-mirrored sheet reads as a
        // rendering bug: rounded on the wrong side, or sliding out of the edge it is glued to.
        val menuLeft by com.armsx2.ui.QuickMenuSide.left
        val slideFrom: (Int) -> Int = if (menuLeft) { w -> -w } else { w -> w }
        AnimatedVisibility(
            visible = shown,
            enter = slideInHorizontally(tween(320, easing = EaseOut), slideFrom),
            exit = slideOutHorizontally(tween(220, easing = EaseIn), slideFrom),
            modifier = Modifier.align(if (menuLeft) Alignment.CenterStart else Alignment.CenterEnd),
        ) {
            if (compact) {
                Surface(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(0.96f)
                        .windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Vertical)),
                    shape = if (menuLeft) RoundedCornerShape(topEnd = 28.dp, bottomEnd = 28.dp)
                        else RoundedCornerShape(topStart = 28.dp, bottomStart = 28.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                    shadowElevation = 22.dp,
                ) {
                    MenuPage(
                        state = state,
                        viewModel = viewModel,
                        compact = true,
                        modifier = Modifier.fillMaxSize(),
                        onOpenFriends = { friendsOpen = true },
                    )
                }
            } else {
                Row(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(0.64f)
                        .widthIn(max = 900.dp)
                        .windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Vertical))
                        .padding(
                            top = 14.dp,
                            start = if (menuLeft) 12.dp else 0.dp,
                            end = if (menuLeft) 0.dp else 12.dp,
                            bottom = 14.dp,
                        ),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Surface(
                        modifier = Modifier.weight(1f).fillMaxHeight(),
                        shape = RoundedCornerShape(28.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                        shadowElevation = 22.dp,
                    ) {
                        MenuPage(
                            state = state,
                            viewModel = viewModel,
                            compact = false,
                            modifier = Modifier.fillMaxSize(),
                            onOpenFriends = { friendsOpen = true },
                        )
                    }
                    Surface(
                        modifier = Modifier.width(76.dp).fillMaxHeight(),
                        shape = RoundedCornerShape(28.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.94f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                        shadowElevation = 18.dp,
                    ) {
                        MenuRail(state.tab, viewModel::selectTab)
                    }
                }
            }
        }

        // Friends, as its own panel over the menu.
        //
        // Composed here rather than as an AlertDialog on purpose: a Dialog gets its own focused
        // window, and a focused window swallows gamepad keys before our input plumbing ever sees
        // them — the pause menu would stop responding to the pad the moment this opened.
        AnimatedVisibility(
            visible = friendsOpen,
            enter = fadeIn(tween(160, easing = EaseOut)),
            exit = fadeOut(tween(140, easing = EaseIn)),
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.72f))
                    .clickable { friendsOpen = false },
            )
        }
        AnimatedVisibility(
            visible = friendsOpen,
            enter = fadeIn(tween(190, easing = EaseOut)),
            exit = fadeOut(tween(150, easing = EaseIn)),
            modifier = Modifier.align(Alignment.Center),
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(if (compact) 0.94f else 0.6f)
                    .widthIn(max = 620.dp)
                    .fillMaxHeight(0.9f)
                    .windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Vertical)),
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                shadowElevation = 24.dp,
            ) {
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                    androidx.compose.runtime.CompositionLocalProvider(
                        com.armsx2.ui.settings.LocalNavLayer provides FRIENDS_NAV_LAYER,
                    ) {
                        Row(
                            Modifier.fillMaxWidth().padding(start = 16.dp, end = 10.dp, top = 14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                str("friends.title"),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                            )
                            // Between the title and Close: whose Discord this is.
                            if (com.armsx2.DiscordPresence.available()) {
                                com.armsx2.ui.friends.SelfChip(
                                    Modifier.weight(1f).padding(horizontal = 12.dp),
                                )
                            } else {
                                Spacer(Modifier.weight(1f))
                            }
                            TextButton(
                                onClick = { friendsOpen = false },
                                modifier = Modifier.controllerFocusable(
                                    "menu.friends.close",
                                    onConfirm = { friendsOpen = false },
                                ),
                            ) { Text(str("action.close")) }
                        }
                        // Hosting sits with Friends: there is no room for another tab in this menu.
                        com.armsx2.remoteplay.RemotePlayHostPanel(
                            Modifier.padding(start = 12.dp, end = 12.dp, top = 10.dp, bottom = 10.dp),
                        )
                        if (com.armsx2.DiscordPresence.available()) {
                            com.armsx2.ui.friends.FriendsPanel(Modifier.padding(horizontal = 12.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MenuPage(
    state: EmulationMenuUiState,
    viewModel: EmulationMenuViewModel,
    compact: Boolean,
    modifier: Modifier,
    onOpenFriends: () -> Unit,
) {
    val tabScrollStates = remember {
        EmulationMenuTab.entries.associateWith {
            ScrollState(initial = InGameOverlay.menuTabScroll[it.name] ?: 0)
        }
    }
    // Remember each tab's scroll offset when the menu closes so reopening a tab (especially
    // the long Fixes list) returns to where you were instead of snapping back to the top.
    androidx.compose.runtime.DisposableEffect(Unit) {
        onDispose {
            tabScrollStates.forEach { (tab, ss) -> InGameOverlay.menuTabScroll[tab.name] = ss.value }
        }
    }
    val scrollState = tabScrollStates.getValue(state.tab)
    // Provide the pane's scroll state to the settings widgets so the Fixes pane's
    // right-stick free-scroll (settingsScrollState / ControllerAutoScroll) drives the
    // pane the user is actually looking at. Per-control bring-into-view handles the
    // primary "keep selection on screen" via the nearest scrollable ancestor already.
    androidx.compose.runtime.CompositionLocalProvider(
        com.armsx2.ui.settings.LocalSettingsScrollState provides scrollState,
    ) {
        Column(
            modifier
                .verticalScroll(scrollState)
                .padding(bottom = 18.dp),
        ) {
            if (compact) CompactMenuTabs(state.tab, viewModel::selectTab)
            MenuHeader(compact, state.hardcore, state.richPresence, state.gameCRC, onOpenFriends)
            HorizontalDivider(
                modifier = Modifier.padding(horizontal = 8.dp),
                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.34f),
            )
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                // Only the panes with rows that take a mark; the others would show a key to nothing.
                if (state.tab != EmulationMenuTab.Controls && state.tab != EmulationMenuTab.Achievements) {
                    com.armsx2.ui.settings.OverrideLegend(inset = 4.dp)
                }
                when (state.tab) {
                    EmulationMenuTab.Session -> SessionPane(state, viewModel)
                    EmulationMenuTab.Graphics -> GraphicsPane(state, viewModel)
                    // The full Fixes settings tab, live-applying via InGameOverlay's
                    // shared Settings state (same as the rest of the overlay); its
                    // controls are SettingsControllerNav items, so the pause menu's
                    // content-pane nav drives them for free.
                    EmulationMenuTab.Fixes -> com.armsx2.ui.settings.FixesTab(InGameOverlay.settingsState)
                    EmulationMenuTab.Performance -> PerformancePane(state, viewModel)
                    EmulationMenuTab.Controls -> ControlsPane(state, viewModel)
                    EmulationMenuTab.Options -> OptionsPane(state, viewModel)
                    EmulationMenuTab.Achievements -> AchievementsPane(state, viewModel)
                }
            }
        }
    }
}

@Composable
private fun CompactMenuTabs(selected: EmulationMenuTab, onSelect: (EmulationMenuTab) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        EmulationMenuTab.entries.forEach { tab ->
            MenuTab(tab, tab == selected, onSelect)
        }
    }
}

@Composable
private fun MenuRail(
    selected: EmulationMenuTab,
    onSelect: (EmulationMenuTab) -> Unit,
) {
    Column(
        Modifier
            .fillMaxHeight()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 8.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        // Centred, not top-aligned: the rail fills the full height, so with the tabs pinned
        // to the top the column left a block of dead space at the bottom once the duplicate
        // All Settings shortcut was removed from under them. Centring keeps the group
        // balanced regardless of how many tabs there are, and still scrolls if it ever
        // outgrows the rail.
        verticalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterVertically),
    ) {
        EmulationMenuTab.entries.forEach { tab ->
            MenuRailTab(tab, tab == selected, onSelect)
        }
    }
}

@Composable
private fun MenuRailTab(tab: EmulationMenuTab, active: Boolean, onSelect: (EmulationMenuTab) -> Unit) {
    val bring = remember { BringIntoViewRequester() }
    val label = str(tab.titleKey)
    LaunchedEffect(active) { if (active) runCatching { bring.bringIntoView() } }
    Surface(
        onClick = { onSelect(tab) },
        modifier = Modifier.size(56.dp).bringIntoViewRequester(bring).semantics { contentDescription = label },
        shape = RoundedCornerShape(18.dp),
        color = if (active) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface.copy(alpha = 0.5f),
        border = BorderStroke(
            if (active) 2.dp else 1.dp,
            if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.34f),
        ),
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = tabGlyph(tab),
                fontSize = 23.sp,
                fontWeight = FontWeight.Bold,
                color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun MenuTab(tab: EmulationMenuTab, active: Boolean, onSelect: (EmulationMenuTab) -> Unit) {
    // Keep the active tab scrolled into view so controller nav reaches tabs that fall off
    // the rail on short screens — e.g. the 7th "Achievements" (RA) tab on a Retroid Pocket
    // in landscape. Mirrors the settings-hub / library camera-follow. Resolves against the
    // nearest scrollable ancestor, so it works for both the vertical rail and the compact
    // horizontal strip.
    val bring = remember { BringIntoViewRequester() }
    LaunchedEffect(active) { if (active) runCatching { bring.bringIntoView() } }
    Surface(
        onClick = { onSelect(tab) },
        modifier = Modifier
            .widthIn(min = 132.dp, max = 210.dp)
            .padding(vertical = 3.dp)
            .bringIntoViewRequester(bring),
        shape = RoundedCornerShape(14.dp),
        color = if (active) MaterialTheme.colorScheme.primaryContainer
        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.56f),
        border = BorderStroke(
            if (active) 1.5.dp else 1.dp,
            if (active) MaterialTheme.colorScheme.primary.copy(alpha = 0.72f)
            else MaterialTheme.colorScheme.outline.copy(alpha = 0.32f),
        ),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 11.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Surface(
                modifier = Modifier.size(30.dp),
                shape = RoundedCornerShape(9.dp),
                color = if (active) MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)
                else MaterialTheme.colorScheme.surface.copy(alpha = 0.72f),
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = tabGlyph(tab),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            Text(
                text = str(tab.titleKey),
                color = if (active) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

// Rail tab icons. No monochrome Unicode exists for gamepad/wrench/trophy/display, so those
// use color emoji (Android's own emoji font draws them); Session keeps its clean text
// glyph. Performance uses the high-voltage emoji so it reads as a yellow lightning bolt.
// Options carries the settings gear; the full-settings shortcut below the rail divider uses
// a distinct "open" glyph so there aren't two gears.
private fun tabGlyph(tab: EmulationMenuTab): String = when (tab) {
    EmulationMenuTab.Session -> "☰"
    EmulationMenuTab.Graphics -> "🖥️"
    EmulationMenuTab.Fixes -> "🔧"
    EmulationMenuTab.Performance -> "⚡"
    EmulationMenuTab.Controls -> "🎮"
    EmulationMenuTab.Options -> "⚙"
    EmulationMenuTab.Achievements -> "🏆"
}

@Composable
private fun MenuHeader(
    compact: Boolean,
    hardcore: Boolean,
    richPresence: String,
    gameCRC: String,
    onOpenFriends: () -> Unit,
) {
    val game = MainActivityRuntime.currentGame.value
    Row(
        Modifier.fillMaxWidth().padding(horizontal = if (compact) 12.dp else 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (game != null) {
            GameCoverArt(game, Modifier.width(if (compact) 38.dp else 44.dp).height(if (compact) 52.dp else 60.dp))
            Spacer(Modifier.width(11.dp))
        }
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    game?.title ?: "PlayStation 2",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f, fill = false),
                )
                if (hardcore) {
                    Spacer(Modifier.width(8.dp))
                    HardcoreBadge()
                }
                // File-type chip after the HC badge (ISO / CHD / …), mirroring the library
                // list view so the pause/RA header shows the same at-a-glance file info.
                game?.let { g ->
                    Spacer(Modifier.width(6.dp))
                    com.armsx2.ui.common.StatusChip(g.extension.ifBlank { g.platform.key.uppercase() })
                }
            }
            // Serial and CRC together: a PNACH is named <SERIAL>_<CRC>.pnach, so the two values
            // needed to name one should not live on separate screens.
            //
            // The live VM CRC is preferred but cannot be relied on: for ISO boots the core hands
            // ELFLoadingOnCPUThread an empty path, so UpdateELFInfo takes its failure branch and
            // leaves s_current_crc at 0 — the emulog shows the loader computing the real CRC and
            // the VM then reporting 00000000. When that happens, identify the image instead, which
            // is the same path the Info tab and the library's long-press sheet already take.
            val resolvedCRC by androidx.compose.runtime.produceState(gameCRC, gameCRC, game?.uri) {
                value = gameCRC.ifBlank {
                    game?.uri?.let { com.armsx2.DiscIdentity.resolve(it, game.serial) }.orEmpty()
                }
            }
            val identity = buildList {
                game?.serial?.takeIf { it.isNotBlank() }?.let(::add)
                resolvedCRC.takeIf { it.isNotBlank() }?.let { add("CRC $it") }
            }.joinToString("  ·  ")
            if (identity.isNotBlank()) {
                Spacer(Modifier.height(2.dp))
                Text(
                    identity,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            // RetroAchievements rich presence — the live "what you're doing" line
            // (e.g. "Pooh & Piglet are in a Scaring Contest"). Restored from the old UI.
            if (richPresence.isNotBlank()) {
                Spacer(Modifier.height(2.dp))
                Text(
                    richPresence,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }

        // Clock + battery, same cluster as the library toolbar. Worth having here specifically:
        // this menu is what you open mid-session on a handheld, so it's exactly when you want to
        // know the time and how much charge is left. Not controllerFocusable — it's a readout.
        Spacer(Modifier.width(8.dp))
        com.armsx2.ui.common.LibraryStatusCluster(
            Modifier.align(Alignment.CenterVertically),
        )

        // Friends, in the header where it is always visible, with the online count on it. Shown
        // even where Discord is not available: remote play hosting lives behind it too, and
        // hosting does not need Discord. The Discord parts inside hide themselves there.
        Spacer(Modifier.width(8.dp))
        Surface(
            onClick = onOpenFriends,
            modifier = Modifier.controllerFocusable(
                "menu.friends",
                RoundedCornerShape(14.dp),
                onConfirm = onOpenFriends,
            ),
            shape = RoundedCornerShape(14.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
        ) {
            Box(Modifier.padding(horizontal = 11.dp, vertical = 9.dp)) {
                com.armsx2.ui.friends.FriendsGlyphWithBadge(
                    color = MaterialTheme.colorScheme.onSurface,
                    glyphSize = 19.sp,
                )
            }
        }
    }
}

@Composable
private fun SessionPane(state: EmulationMenuUiState, viewModel: EmulationMenuViewModel) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val gsDumpQueued = str("gsdump.quick.queued")
    ActionGrid(
        actions = listOf(
            MenuAction(str("action.resume"), str("action.play"), "▶", Success, viewModel::resume),
            MenuAction(
                str("action.fastForward"),
                if (MainActivityRuntime.fastForwardToggleActive) str("action.fastForward.on") else str("action.fastForward.detail"),
                "⏩",
                if (MainActivityRuntime.fastForwardToggleActive) Success else null,
            ) { MainActivityRuntime.instance?.toggleFastForward(); viewModel.resume() },
            MenuAction(str("memcard.restart"), str("action.reset"), "↻", null, MainActivityRuntime::restart),
            MenuAction(str("action.swapDisc"), str("action.swapDisc.detail"), "⏏", null, MainActivityRuntime::promptSwapDisc),
            // Here and not only in Settings > Renderer, where it sat at the bottom of a long page:
            // a GS dump is what gets asked for when someone reports a graphics bug, and this is
            // one tap from the game. It also resumes, because the dump is of the NEXT frame the GS
            // draws, and none is drawn while this menu holds the game paused.
            //
            // It is now a choice: keep the dump in the snaps folder as before, or start a problem
            // report with a fresh dump of this scene.
            MenuAction(str("renderer.gsDump.label"), str("gsdump.quick.detail"), "⧉", null) {
                com.armsx2.ui.bugreport.askGsDumpChoice {
                    runCatching { kr.co.iefriends.pcsx2.NativeApp.captureGsDump(1) }
                    android.widget.Toast.makeText(context, gsDumpQueued, android.widget.Toast.LENGTH_LONG).show()
                    viewModel.resume()
                }
            },
            // Best place to report graphics and slowness: the scene is still here to capture.
            MenuAction(str("bugreport.menu.title"), str("bugreport.menu.detail"), "⚑", null) {
                com.armsx2.ui.bugreport.BugReportFlow.openInGame(context)
            },
        ) + arcadeActions(viewModel) + listOf(
            MenuAction(str("action.close"), MainActivityRuntime.currentGame.value?.title.orEmpty(), "■", Danger) {
                MainActivityRuntime.closeGame()
            },
        ),
    )
    // On-screen display — a single universal on/off (old-UI style); the per-stat
    // toggles live in All Settings. Plus a frame-limit switch so fast-forward is one
    // tap away.
    SectionCard(str("tab.overlay")) {
        // #357: the pause button replaced the settings cog, so it's front-and-centre here. This is
        // "tap to reveal", NOT show/hide: on = the glyph stays hidden until you tap its top-right
        // corner, which surfaces it. Either way that corner always opens this menu, so unlike the
        // old on/off toggle there's no setting here that can lock you out of it.
        MenuSwitchRow(str("pad.pauseTapToReveal.label"), TouchControls.pauseTapToReveal.value) {
            TouchControls.setPauseTapToReveal(it)
        }
        Spacer(Modifier.height(6.dp))
        // OSD mode selector — one control (Full / Minimal / Custom / Off) in place of the old
        // master + simple toggles, cycled here and by the "Cycle Perf Stats (OSD)" hotkey. Custom
        // = the detailed per-stat selection from All Settings > On-Screen.
        val osdModes = com.armsx2.ui.InGameOverlay.OsdMode.entries
        val osdModeIndex = osdModes.indexOf(com.armsx2.ui.InGameOverlay.osdMode.value).coerceAtLeast(0)
        MenuCycleRow(
            title = str("overlay.master.label"),
            valueLabel = com.armsx2.ui.InGameOverlay.osdModeLabel(osdModes[osdModeIndex]),
        ) { step ->
            val size = osdModes.size
            val next = ((osdModeIndex + step) % size + size) % size
            com.armsx2.ui.InGameOverlay.setOsdMode(osdModes[next])
        }
        Spacer(Modifier.height(6.dp))
        // The second-screen panel, one tap away. Docked to a monitor over USB-C it goes to the
        // monitor, and turning it off meant unplugging or digging into App settings (SoraNo).
        MenuSwitchRow(str("secondScreen.label"), com.armsx2.SecondScreen.enabled.value) { on ->
            com.armsx2.SecondScreen.set(context.applicationContext, on)
        }
        Spacer(Modifier.height(6.dp))
        MenuSwitchRow(str("perf.frameLimit.label"), state.settings.frameLimit.frameLimitEnable, field = "frameLimitEnable") { value ->
            viewModel.updateSettings { it.copy(frameLimit = it.frameLimit.copy(frameLimitEnable = value)) }
        }
        Spacer(Modifier.height(6.dp))
        // Fast-forward SPEED — how fast the FF hotkey/button runs: 2..10x, or Unlimited (the
        // default, uncapped) at the top. Global pref; re-applied live if FF is currently engaged.
        var ffSpeed by remember { mutableStateOf(MainActivityRuntime.fastForwardSpeed()) }
        val ffUnlimitedLabel = str("common.unlimited") // hoisted: str() is @Composable, can't run in the formatter lambda
        com.armsx2.ui.settings.IntSliderRow(
            label = str("perf.ffSpeed.label"),
            value = ffSpeed,
            min = 2,
            max = MainActivityRuntime.FF_SPEED_UNLIMITED,
            valueFormatter = { if (it >= MainActivityRuntime.FF_SPEED_UNLIMITED) ffUnlimitedLabel else "${it}×" },
            onChange = { v ->
                ffSpeed = v
                MainActivityRuntime.setFastForwardSpeed(v)
                if (MainActivityRuntime.fastForwardToggleActive)
                    runCatching { kr.co.iefriends.pcsx2.NativeApp.speedhackLimitermode(MainActivityRuntime.ffLimiterMode()) }
            },
        )
        Spacer(Modifier.height(6.dp))
        // OSD colour, cycled in place. Shares the palette with the All Settings picker rather
        // than carrying its own copy. Safe to add here: this card's rows are plain switches with
        // their own callbacks, and every control on this pane — grid rows included — now
        // registers its own id with the nav registry, so inserting a row cannot shift what any
        // other row does.
        val osdColorIndex = com.armsx2.ui.settings.OSD_COLORS
            .indexOf(state.settings.osd.osdColor).coerceAtLeast(0)
        MenuCycleRow(
            title = str("overlay.osdColor.label"),
            valueLabel = str(com.armsx2.ui.settings.OSD_COLOR_LABEL_KEYS[osdColorIndex]),
            field = "osdColor",
        ) { step ->
            val size = com.armsx2.ui.settings.OSD_COLORS.size
            val next = ((osdColorIndex + step) % size + size) % size
            viewModel.updateSettings { it.copy(osd = it.osd.copy(osdColor = com.armsx2.ui.settings.OSD_COLORS[next])) }
        }
        // Where the stats block sits, cycled in place. In the quick menu and not only in All
        // Settings because the moment you want to move the OSD is the moment it is covering
        // something you are trying to read — which is mid-game, not in a settings screen.
        val osdPosIndex = com.armsx2.ui.settings.OSD_POSITIONS
            .indexOf(state.settings.osd.osdPosition).coerceAtLeast(0)
        MenuCycleRow(
            title = str("overlay.osdPosition.label"),
            valueLabel = str(com.armsx2.ui.settings.OSD_POSITION_LABEL_KEYS[osdPosIndex]),
            field = "osdPosition",
        ) { step ->
            val size = com.armsx2.ui.settings.OSD_POSITIONS.size
            val next = ((osdPosIndex + step) % size + size) % size
            viewModel.updateSettings { it.copy(osd = it.osd.copy(osdPosition = com.armsx2.ui.settings.OSD_POSITIONS[next])) }
        }
        // Which edge this very panel docks to. Cycling it while the panel is open moves the
        // panel under your thumb, which is the only way to judge the choice.
        val menuSide by com.armsx2.ui.QuickMenuSide.left
        MenuCycleRow(
            title = str("overlay.quickMenuSide.label"),
            valueLabel = str(if (menuSide) "overlay.quickMenuSide.left" else "overlay.quickMenuSide.right"),
        ) { _ -> com.armsx2.ui.QuickMenuSide.set(!menuSide) }
    }
    SectionCard(str("savestate.title.loadManage")) {
        // When each slot was last written. Ten chips numbered 1..10 say nothing about which
        // hold anything or how old they are, so picking a slot to overwrite after a long
        // session was guesswork -- the Save Manager has had the dates all along, but the quick
        // picker is where the choice actually gets made. Read off disk once per menu open;
        // the read is blocking, hence produceState rather than a composition-time call.
        // ★ getGamePathSlot, NOT SaveCatalog.
        //
        // SaveCatalog exists for the LIBRARY, where nothing is booted and the only way to
        // find states is to match `<serial> (CRC).NN.p2s` on disk. In here a VM is running, so
        // the native side already knows the exact path for each slot — and it is authoritative
        // where the filename match is a guess that silently returns nothing when the serial is
        // absent or formatted differently, which is what made this show "Empty" for every slot.
        val slotStamps by androidx.compose.runtime.produceState(
            // Re-read when the menu's slot selection changes, which is the only thing that
            // happens in here after a save; a save also bumps the file, and the menu is short-
            // lived enough that one read per open is the right granularity.
            initialValue = emptyMap<Int, Long>(), state.saveSlot,
        ) {
            value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                runCatching {
                    (0..9).mapNotNull { slot ->
                        val path = kr.co.iefriends.pcsx2.NativeApp.getGamePathSlot(slot)
                        if (path.isNullOrBlank()) return@mapNotNull null
                        val f = java.io.File(path)
                        if (f.isFile && f.lastModified() > 0L) slot to f.lastModified() else null
                    }.toMap()
                }.getOrDefault(emptyMap())
            }
        }
        Text(
            "${str("memcard.slot1").substringBefore(' ')} ${state.saveSlot + 1}",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface,
        )
        Text(
            slotStamps[state.saveSlot]?.let {
                java.text.SimpleDateFormat("d MMM yyyy, HH:mm", java.util.Locale.getDefault())
                    .format(java.util.Date(it))
            } ?: str("savestate.slot.empty"),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(8.dp))
        Row(
            Modifier
                .fillMaxWidth()
                .bleedHorizontal(13.dp)
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 13.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            repeat(10) { slot ->
                OptionChip(
                    // A dot marks a slot that holds something, so the row shows what is used
                    // without having to select each one to find out.
                    label = if (slotStamps.containsKey(slot)) "${slot + 1} •" else "${slot + 1}",
                    selected = slot == state.saveSlot,
                    controllerId = "pause.saveslot.$slot",
                    onClick = { viewModel.setSaveSlot(slot) },
                )
            }
        }
        Spacer(Modifier.height(9.dp))
        // Save / Load open the rich slot picker (thumbnails + autosave + the
        // auto-save/-load toggles), matching the old UI. The slot chips above stay
        // the quick-slot selector used by the on-screen / hotkey quick-save.
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CompactAction(str("savestate.title.save"), "↥", Modifier.weight(1f)) {
                com.armsx2.ui.WindowImpl.openInGameScreen(com.armsx2.ui.InGameScreen.SaveState)
            }
            CompactAction(str("touch.stateAction.load"), "↧", Modifier.weight(1f)) {
                com.armsx2.ui.WindowImpl.openInGameScreen(com.armsx2.ui.InGameScreen.LoadState)
            }
        }
    }
}

@Composable
private fun GraphicsPane(state: EmulationMenuUiState, viewModel: EmulationMenuViewModel) {
    val settings = state.settings
    HorizontalOptions(
        title = str("tab.renderer"),
        options = listOf(
            "auto" to str("backend.renderer.auto"),
            "vulkan" to "Vulkan",
            "opengl" to "OpenGL",
            "software" to str("backend.renderer.software"),
        ),
        selected = settings.output.renderer,
        onSelect = viewModel::setRenderer,
        field = "renderer",
    )
    // GPU driver manager (download/import/select) — Vulkan only — plus Apply &
    // Restart, since renderer + driver changes only take effect on renderer init.
    // For OpenGL the "custom driver" is ANGLE (GLES-on-Vulkan), same picker shape.
    if (settings.output.renderer == "vulkan") {
        com.armsx2.ui.common.DriverManagerSection()
    } else if (settings.output.renderer == "opengl") {
        com.armsx2.ui.common.AngleDriverSection(settings.display.useAngleOpenGL) { on ->
            viewModel.updateSettings { it.copy(display = it.display.copy(useAngleOpenGL = on)) }
        }
    }
    // GS Multi-threading (GV7 front/back split). Restart-required like the renderer /
    // driver above, so it lives in the same group — hit Apply & Restart below to apply.
    // Off (0) = single-threaded; on (any other value, written as 1) = GS rendering on a
    // second thread.
    MenuSwitchRow(
        str("renderer.gsBackThread.label"),
        settings.display.gsBackThreadMode != 0,
        description = str("renderer.gsBackThread.description"),
        field = "gsBackThreadMode",
    ) { on ->
        viewModel.updateSettings { it.copy(display = it.display.copy(gsBackThreadMode = if (on) 1 else 0)) }
    }
    // Coalesce Render Passes is deliberately NOT here. It only helps Dirge of Cerberus, and the
    // game database already turns it on for Dirge, so it lives in All Settings > Renderer >
    // advanced and nowhere a player tuning performance would reach for it.
    CompactAction(str("backend.applyRestart"), "↻", Modifier.fillMaxWidth(), MainActivityRuntime::restart)
    HorizontalOptions(
        title = str("renderer.upscale.label"),
        // Share the full settings-tab list so the sub-native 0.25/0.5/0.75/Native
        // options aren't dropped in the in-game quick menu.
        options = com.armsx2.ui.settings.UPSCALE_OPTIONS.map { it.value to it.label },
        selected = settings.output.upscaleFloat,
        onSelect = viewModel::setUpscale,
        field = "upscaleFloat",
    )
    // Custom internal resolution, same control as the settings tab — the quick menu only offered
    // the preset steps, so a value between them (or set per-game) could be neither seen nor
    // changed from in-game. Percentage of native: 107% is roughly true 480p height.
    com.armsx2.ui.settings.IntSliderRow(
        label = str("renderer.upscale.customScale"),
        value = (settings.output.upscaleFloat * 100f).roundToInt().coerceIn(25, 800),
        min = 25,
        max = 800,
        description = str("renderer.upscale.customScale.description"),
        valueFormatter = { "$it%" },
        onReset = { viewModel.setUpscale(1.0f) },
        onChange = { pct -> viewModel.setUpscale(pct / 100f) },
        field = "upscaleFloat",
    )
    // Texture Upscaling, under the resolution it is paired with: RAISR's 4x only pays off at a high
    // one, and finding that out means switching both while the game runs. Same choices and values as
    // the Renderer tab's row (the core's GSTextureUpscaleMode: 0 Off, 1 2x, 2 4x). Hardware renderers
    // only, so the software one does not offer it.
    if (settings.output.renderer != "software") {
        HorizontalOptions(
            title = str("renderer.textureUpscale.label"),
            options = listOf(
                0 to str("common.off"),
                1 to str("renderer.textureUpscale.raisr2x"),
                2 to str("renderer.textureUpscale.raisr4x"),
            ),
            selected = settings.graphics.textureUpscale.coerceIn(0, 2),
            onSelect = { v -> viewModel.updateSettings { it.copy(graphics = it.graphics.copy(textureUpscale = v)) } },
            field = "textureUpscale",
        )
    }
    // FSR sits with the resolution controls rather than the effects, because that is what it
    // is: the two rows above choose how big the frame is RENDERED, and this chooses how it
    // gets to the screen. In full settings it lives under Display Effects next to CAS, which
    // is the wrong shelf for finding it while you are looking at the framerate.
    // "auto" is the DEFAULT and resolves to Vulkan on Android, so gating on the literal string
    // "vulkan" hid this row from almost everyone — which is exactly what happened. Only OpenGL
    // and software genuinely cannot run it.
    if (settings.output.renderer != "opengl" && settings.output.renderer != "software") {
        // A picker, matching the Renderer tab. This was a switch while FSR1 was the only
        // upscaler; with SGSR beside it there are three mutually exclusive choices, and this
        // screen is the SECOND place that has to learn about a new one -- the settings tab has
        // its own copy of the same control, and updating only that one leaves the in-game menu
        // silently unable to reach the new option.
        val sgsrOn = settings.graphics.upscaler == com.armsx2.config.Settings.UPSCALER_SGSR ||
            settings.graphics.upscaler == com.armsx2.config.Settings.UPSCALER_SGSR_EDGE
        val fsr1On = settings.graphics.upscaler == com.armsx2.config.Settings.UPSCALER_FSR1 || sgsrOn
        HorizontalOptions(
            title = str("renderer.upscaler.label"),
            options = listOf(
                com.armsx2.config.Settings.UPSCALER_OFF to str("common.off"),
                com.armsx2.config.Settings.UPSCALER_FSR1 to "FSR 1",
                com.armsx2.config.Settings.UPSCALER_SGSR to "SGSR",
                com.armsx2.config.Settings.UPSCALER_SGSR_EDGE to "SGSR Edge",
            ),
            selected = if (fsr1On) settings.graphics.upscaler else com.armsx2.config.Settings.UPSCALER_OFF,
            onSelect = { v -> viewModel.updateSettings { it.copy(graphics = it.graphics.copy(upscaler = v)) } },
            field = "upscaler",
        )
        if (fsr1On) {
            // Separate settings, separate ranges — see the note in RendererTab.
            if (sgsrOn) {
                com.armsx2.ui.settings.IntSliderRow(
                    label = str("renderer.sgsr.sharpness.label"),
                    value = settings.graphics.sgsrSharpness.coerceIn(0, 200),
                    min = 0,
                    max = 200,
                    valueFormatter = { "$it%" },
                    onChange = { pct -> viewModel.updateSettings { it.copy(graphics = it.graphics.copy(sgsrSharpness = pct)) } },
                    field = "sgsrSharpness",
                )
            } else {
                com.armsx2.ui.settings.IntSliderRow(
                    label = str("renderer.fsr1.sharpness.label"),
                    value = settings.graphics.fsrSharpness.coerceIn(0, 100),
                    min = 0,
                    max = 100,
                    valueFormatter = { "$it%" },
                    onChange = { pct -> viewModel.updateSettings { it.copy(graphics = it.graphics.copy(fsrSharpness = pct)) } },
                    field = "fsrSharpness",
                )
            }
        }
    }
    // Texture packs, straight after the resolution they are usually paired with. They used to be
    // split between the bottom of this page (the switches) and the Options page (the manager),
    // which for one of the most-used features on the device was two places too deep.
    CompactAction(str("renderer.section.texturePacks"), "▣", Modifier.fillMaxWidth(), viewModel::openTextures)
    MenuSwitchRow(str("renderer.loadTexturePacks.label"), settings.graphics.loadTextureReplacements, field = "loadTextureReplacements") {
        viewModel.updateSettings { current -> current.copy(graphics = current.graphics.copy(loadTextureReplacements = it)) }
    }
    MenuSwitchRow(str("renderer.asyncTextureLoading.label"), settings.graphics.loadTextureReplacementsAsync, field = "loadTextureReplacementsAsync") {
        viewModel.updateSettings { current -> current.copy(graphics = current.graphics.copy(loadTextureReplacementsAsync = it)) }
    }
    MenuSwitchRow(str("renderer.precacheTexturePacks.label"), settings.graphics.precacheTextureReplacements, field = "precacheTextureReplacements") {
        viewModel.updateSettings { current -> current.copy(graphics = current.graphics.copy(precacheTextureReplacements = it)) }
    }
    HorizontalOptions(
        title = str("renderer.displayMode.label"),
        options = listOf(
            0 to str("setup.aspect.stretch"),
            1 to str("setup.aspect.auto"),
            2 to "4:3",
            3 to "16:9",
            4 to "10:7",
            5 to "21:9",
            6 to "20:9",
            7 to "19.5:9",
            8 to "Custom",
        ),
        selected = settings.output.aspectRatio,
        onSelect = viewModel::setAspectRatio,
        field = "aspectRatio",
    )
    // Screen orientation from in-game: whether a game plays better in portrait or landscape is
    // found out by trying it, and that meant leaving for All Settings each time. Same values as
    // the Renderer tab's row, and applied straight away the same way.
    HorizontalOptions(
        title = str("renderer.orientation.label"),
        options = listOf(
            0 to str("renderer.orientation.device"),
            1 to str("renderer.orientation.landscape"),
            2 to str("renderer.orientation.portrait"),
            3 to str("renderer.orientation.autoRotate"),
        ),
        selected = settings.output.orientation.coerceIn(0, 3),
        onSelect = { value ->
            viewModel.updateSettings { it.copy(output = it.output.copy(orientation = value)) }
            MainActivityRuntime.instance?.applyEmulationOrientation()
        },
        field = "orientation",
    )
    // Overlay artwork, switchable from in-game — trying bezels means seeing them ON the game, and
    // having to leave for All Settings each time made that unusable. Import still lives in the
    // settings tab (it opens a file picker); this is the picker for what is already imported.
    run {
        val overlayCtx = androidx.compose.ui.platform.LocalContext.current
        val entries = remember { com.armsx2.OverlayRepo.list(overlayCtx) }
        // Shown even with nothing imported. Hiding it when the list was empty is why this looked
        // absent from the in-game menu entirely — with no overlays there was no row to find, and
        // no hint that the feature existed or where to add one.
        HorizontalOptions(
            title = str("renderer.overlayArt.label"),
            options = listOf("" to str("renderer.overlayArt.none")) +
                entries.map { it.imagePath to it.name },
            selected = com.armsx2.OverlayRepo.activePath.value,
            onSelect = { com.armsx2.OverlayRepo.setActive(it) },
        )
        if (entries.isEmpty()) {
            Text(
                str("renderer.overlayArt.emptyHint"),
                color = Color(0xFF9AA0A6),
                fontSize = 12.sp,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
            )
        }
    }
    HorizontalOptions(
        title = str("renderer.blendingAccuracy.label"),
        options = listOf("Minimum", "Basic", "Medium", "High", str("fixes.opt.full"), str("fixes.opt.max")).mapIndexed { index, label -> index to label },
        selected = settings.graphics.accurateBlendingUnit,
        onSelect = viewModel::setBlending,
        field = "accurateBlendingUnit",
    )
    HorizontalOptions(
        title = str("renderer.textureFiltering.label"),
        options = listOf("Nearest", str("fixes.opt.forced"), "PS2", str("fixes.opt.sprite")).mapIndexed { index, label -> index to label },
        selected = settings.graphics.textureFiltering,
        onSelect = viewModel::setTextureFiltering,
        field = "textureFiltering",
    )
    HorizontalOptions(
        title = str("renderer.texturePreloading.label"),
        options = listOf(str("fixes.opt.off"), "Partial", str("fixes.opt.full")).mapIndexed { index, label -> index to label },
        selected = settings.graphics.texturePreloading,
        onSelect = viewModel::setTexturePreloading,
        field = "texturePreloading",
    )
    HorizontalOptions(
        title = str("renderer.hardwareDownloadMode.label"),
        // Index == GSHardwareDownloadMode, so the order is load-bearing. "Async" is 5 and must stay
        // last; it is experimental (non-blocking readback) and is not the default.
        options = listOf("Accurate", "Force Full", "No Readbacks", "Unsync", "Disabled", "Async")
            .mapIndexed { index, label -> index to label },
        selected = settings.graphics.hardwareDownloadMode,
        onSelect = viewModel::setHardwareDownloadMode,
        field = "hardwareDownloadMode",
    )
    HorizontalOptions(
        title = str("renderer.deinterlacing.label"),
        options = listOf("Auto", "Off", "Weave TFF", "Weave BFF", "Bob TFF", "Bob BFF", "Blend TFF", "Blend BFF", "Adapt TFF", "Adapt BFF")
            .mapIndexed { index, label -> index to label },
        selected = settings.output.deinterlaceMode,
        onSelect = { value -> viewModel.updateSettings { it.copy(output = it.output.copy(deinterlaceMode = value)) } },
        field = "deinterlaceMode",
    )
    HorizontalOptions(
        title = str("renderer.displayFilter.label"),
        options = listOf("Nearest", "Smooth", "Sharp").mapIndexed { index, label -> index to label },
        selected = settings.graphics.displayBilinear,
        onSelect = { value -> viewModel.updateSettings { it.copy(graphics = it.graphics.copy(displayBilinear = value)) } },
        field = "displayBilinear",
    )
    HorizontalOptions(
        title = str("renderer.tvShader.label"),
        options = listOf("Off", "Scanline", "Diagonal", "Tri", "Wave", "Lottes", "4xRGSS", "NxAGSS")
            .mapIndexed { index, label -> index to label },
        selected = settings.graphics.tvShader,
        onSelect = { value -> viewModel.updateSettings { it.copy(graphics = it.graphics.copy(tvShader = value)) } },
        field = "tvShader",
    )
    HorizontalOptions(
        title = str("fixes.dithering.label"),
        options = listOf(str("fixes.opt.off"), str("fixes.opt.scaled"), str("fixes.opt.unscaled"), str("fixes.opt.force32"))
            .mapIndexed { index, label -> index to label },
        selected = settings.hwFixes.dithering,
        onSelect = { value -> viewModel.updateSettings { it.copy(hwFixes = it.hwFixes.copy(dithering = value)) } },
        field = "dithering",
    )
    MenuSwitchRow(str("renderer.hwMipmapping.label"), settings.graphics.hwMipmap, field = "hwMipmap") {
        viewModel.updateSettings { current -> current.copy(graphics = current.graphics.copy(hwMipmap = it)) }
    }
    MenuSwitchRow(str("fixes.integerScaling.label"), settings.hwFixes.integerScaling, field = "integerScaling") {
        viewModel.updateSettings { current -> current.copy(hwFixes = current.hwFixes.copy(integerScaling = it)) }
    }
    MenuSwitchRow("VSync", settings.display.vsyncEnable, field = "vsyncEnable") {
        viewModel.updateSettings { current -> current.copy(display = current.display.copy(vsyncEnable = it)) }
    }
    MenuSwitchRow(str("renderer.shadeboost.label"), settings.graphics.shadeBoost, field = "shadeBoost") {
        viewModel.updateSettings { current -> current.copy(graphics = current.graphics.copy(shadeBoost = it)) }
    }
    MenuSwitchRow(str("fixes.antiBlur.label"), settings.display.antiBlur, field = "antiBlur") {
        viewModel.updateSettings { current -> current.copy(display = current.display.copy(antiBlur = it)) }
    }
    MenuSwitchRow(str("fixes.screenOffsets.label"), settings.display.screenOffsets, field = "screenOffsets") {
        viewModel.updateSettings { current -> current.copy(display = current.display.copy(screenOffsets = it)) }
    }
    MenuSwitchRow(str("fixes.showOverscan.label"), settings.display.showOverscan, field = "showOverscan") {
        viewModel.updateSettings { current -> current.copy(display = current.display.copy(showOverscan = it)) }
    }
    MenuSwitchRow(str("fixes.syncToHostRefresh.label"), settings.display.syncToHostRefresh, field = "syncToHostRefresh") {
        viewModel.updateSettings { current -> current.copy(display = current.display.copy(syncToHostRefresh = it)) }
    }
    // Side-by-side VR, here as well as in Settings so it can be set up against the game itself.
    MenuSwitchRow(str("renderer.vr.label"), settings.output.vrSideBySide, field = "vrSideBySide") {
        viewModel.updateSettings { current -> current.copy(output = current.output.copy(vrSideBySide = it)) }
    }
    if (settings.output.vrSideBySide) {
        com.armsx2.ui.settings.IntSliderRow(
            label = str("renderer.vr.size"),
            value = settings.output.vrSize,
            min = 30,
            max = 100,
            valueFormatter = { "${it}%" },
            field = "vrSize",
        ) { v -> viewModel.updateSettings { current -> current.copy(output = current.output.copy(vrSize = v)) } }
        com.armsx2.ui.settings.IntSliderRow(
            label = str("renderer.vr.distance"),
            value = settings.output.vrDistance,
            min = -100,
            max = 100,
            field = "vrDistance",
        ) { v -> viewModel.updateSettings { current -> current.copy(output = current.output.copy(vrDistance = v)) } }
        com.armsx2.ui.settings.IntSliderRow(
            label = str("renderer.vr.height"),
            value = settings.output.vrHeight,
            min = -100,
            max = 100,
            field = "vrHeight",
        ) { v -> viewModel.updateSettings { current -> current.copy(output = current.output.copy(vrHeight = v)) } }
    }
    // RetroArch shaders, end-to-end in-game: toggle → pick a preset → download more.
    // Same composables the Settings renderer tab renders (single definition in ui/common);
    // only the save lambda differs. updateSettings routes through InGameOverlay.saveSettings,
    // which persists via ConfigStore.save(scope, serial) — honouring the overlay's
    // Global/Game scope — and live-applies with Settings.applyTo(). Identical to how every
    // other row in this pane (shadeboost, tvShader, dithering…) saves; both GS keys ride
    // writeGsToNative(), and the device rebuilds the chain on the next frame, so a preset
    // change is live with no restart.
    com.armsx2.ui.common.ShaderChainSection(
        enabled = settings.graphics.shaderChainEnabled,
        preset = settings.graphics.shaderChainPreset,
        params = settings.graphics.shaderChainParams,
        onEnabledChange = { on -> viewModel.updateSettings { it.copy(graphics = it.graphics.copy(shaderChainEnabled = on)) } },
        onPresetChange = { path -> viewModel.updateSettings { it.copy(graphics = it.graphics.copy(shaderChainPreset = path)) } },
        onParamsChange = { next -> viewModel.updateSettings { it.copy(graphics = it.graphics.copy(shaderChainParams = next)) } },
    )
    com.armsx2.ui.common.ShaderManagerSection()
}

@Composable
private fun PerformancePane(state: EmulationMenuUiState, viewModel: EmulationMenuViewModel) {
    val settings = state.settings
    MenuSwitchRow(str("perf.autoTune.label"), settings.emuCore.autoTune, description = str("perf.autoTune.description"), field = "autoTune") {
        viewModel.updateSettings { current -> current.copy(emuCore = current.emuCore.copy(autoTune = it)) }
    }
    SectionCard(str("perf.speedLimit.label"), field = "nominalSpeedPercent") {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (settings.frameLimit.frameLimitEnable) "${settings.frameLimit.nominalSpeedPercent}%" else str("setup.toggle.off"),
                modifier = Modifier.weight(1f),
                color = MaterialTheme.colorScheme.primary,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
            )
            Switch(
                checked = settings.frameLimit.frameLimitEnable,
                onCheckedChange = { enabled ->
                    viewModel.updateSettings { it.copy(frameLimit = it.frameLimit.copy(frameLimitEnable = enabled)) }
                },
            )
        }
        Spacer(Modifier.height(8.dp))
        HorizontalOptionRow(
            options = listOf(50, 75, 90, 100, 110, 125, 150, 200).map { it to "$it%" },
            selected = settings.frameLimit.nominalSpeedPercent,
            keyPrefix = str("perf.speedLimit.label"),
            onSelect = viewModel::setSpeed,
        )
    }
    HorizontalOptions(
        title = str("perf.displayFpsCap.label"),
        options = listOf(0, 20, 30, 45, 60, 90, 120).map {
            it to if (it == 0) str("setup.toggle.off") else "$it FPS"
        },
        selected = settings.frameLimit.fpsLimit,
        onSelect = viewModel::setFpsLimit,
        field = "fpsLimit",
    )
    HorizontalOptions(
        title = str("perf.frameSkip.label"),
        options = (0..5).map { it to if (it == 0) str("setup.toggle.off") else "$it" },
        selected = settings.frameLimit.frameSkip,
        onSelect = viewModel::setFrameSkip,
        field = "frameSkip",
    )
    FramerateSlider(
        title = str("perf.ntscFramerate.label"),
        value = settings.output.framerateNtsc,
        onValue = { value -> viewModel.updateSettings { it.copy(output = it.output.copy(framerateNtsc = value)) } },
        field = "framerateNtsc",
    )
    FramerateSlider(
        title = str("perf.palFramerate.label"),
        value = settings.output.frameratePal,
        onValue = { value -> viewModel.updateSettings { it.copy(output = it.output.copy(frameratePal = value)) } },
        field = "frameratePal",
    )
    HorizontalOptions(
        title = str("perf.eeCycleRate.label"),
        options = (-3..3).map { it to if (it > 0) "+$it" else "$it" },
        selected = settings.cpu.eeCycleRate,
        onSelect = viewModel::setEeCycleRate,
        field = "eeCycleRate",
    )
    HorizontalOptions(
        title = str("perf.eeCycleSkip.label"),
        options = (0..3).map { it to "$it" },
        selected = settings.cpu.eeCycleSkip,
        onSelect = viewModel::setEeCycleSkip,
        field = "eeCycleSkip",
    )
    HorizontalOptions(
        title = str("perf.eeFpuClamping.label"),
        options = listOf(str("perf.clamp.none"), str("perf.clamp.normal"), str("perf.clamp.extra"), str("perf.clamp.full"), str("perf.clamp.exact"))
            .mapIndexed { index, label -> index to label },
        selected = settings.cpu.eeClampMode,
        onSelect = { value -> viewModel.updateSettings { it.copy(cpu = it.cpu.copy(eeClampMode = value)) } },
        field = "eeClampMode",
    )
    HorizontalOptions(
        title = str("perf.vuClamping.label"),
        options = listOf(str("perf.clamp.none"), str("perf.clamp.normal"), str("perf.clamp.extra"), str("perf.clamp.extraSign"), str("perf.clamp.exact"))
            .mapIndexed { index, label -> index to label },
        selected = settings.cpu.vuClampMode,
        onSelect = { value -> viewModel.updateSettings { it.copy(cpu = it.cpu.copy(vuClampMode = value)) } },
        field = "vuClampMode",
    )
    HorizontalOptions(
        title = str("perf.vu1Clamping.label"),
        options = listOf(str("perf.clamp.followVu0"), str("perf.clamp.none"), str("perf.clamp.normal"), str("perf.clamp.extra"), str("perf.clamp.extraSign"), str("perf.clamp.exact"))
            .mapIndexed { index, label -> index - 1 to label },
        selected = settings.cpu.vu1ClampMode,
        onSelect = { value -> viewModel.updateSettings { it.copy(cpu = it.cpu.copy(vu1ClampMode = value)) } },
        field = "vu1ClampMode",
    )
    HorizontalOptions(
        title = str("perf.eeFpuRoundMode.label"),
        options = listOf(str("perf.round.nearest"), str("perf.round.negative"), str("perf.round.positive"), str("perf.round.chop"))
            .mapIndexed { index, label -> index to label },
        selected = settings.emuCore.eeFpuRoundMode,
        onSelect = { value -> viewModel.updateSettings { it.copy(emuCore = it.emuCore.copy(eeFpuRoundMode = value)) } },
        field = "eeFpuRoundMode",
    )
    MenuSwitchRow(str("perf.hack.mtvu"), settings.cpu.mtvu, field = "mtvu") {
        viewModel.updateSettings { current -> current.copy(cpu = current.cpu.copy(mtvu = it)) }
    }
    MenuSwitchRow(str("perf.hack.iopThread"), settings.cpu.iopThread, field = "iopThread") {
        viewModel.updateSettings { current -> current.copy(cpu = current.cpu.copy(iopThread = it)) }
    }
    MenuSwitchRow(str("perf.hack.vuAot"), settings.cpu.vuAot, description = str("perf.hack.vuAot.desc"), field = "vuAot") {
        viewModel.updateSettings { current -> current.copy(cpu = current.cpu.copy(vuAot = it)) }
    }
    MenuSwitchRow(str("perf.hack.instantVu1"), settings.cpu.vu1Instant, field = "vu1Instant") {
        viewModel.updateSettings { current -> current.copy(cpu = current.cpu.copy(vu1Instant = it)) }
    }
    MenuSwitchRow(str("perf.hack.fastCdvd"), settings.cpu.fastCDVD, field = "fastCDVD") {
        viewModel.updateSettings { current -> current.copy(cpu = current.cpu.copy(fastCDVD = it)) }
    }
    MenuSwitchRow(str("perf.hack.skipDupeFrames"), settings.emuCore.skipDuplicateFrames, field = "skipDuplicateFrames") {
        viewModel.updateSettings { current -> current.copy(emuCore = current.emuCore.copy(skipDuplicateFrames = it)) }
    }
    MenuSwitchRow(str("perf.hack.vuFlagHack"), settings.cpu.vuFlagHack, field = "vuFlagHack") {
        viewModel.updateSettings { current -> current.copy(cpu = current.cpu.copy(vuFlagHack = it)) }
    }
    MenuSwitchRow(str("perf.hack.intcStat"), settings.cpu.intcStat, field = "intcStat") {
        viewModel.updateSettings { current -> current.copy(cpu = current.cpu.copy(intcStat = it)) }
    }
    MenuSwitchRow(str("perf.hack.waitLoop"), settings.cpu.waitLoop, field = "waitLoop") {
        viewModel.updateSettings { current -> current.copy(cpu = current.cpu.copy(waitLoop = it)) }
    }
    // Frame generation, in its own card: it changes what is PRESENTED rather than what is
    // emulated, so it does not belong among the speedhacks above. Github flavour only — the
    // card is a no-op stub in the Play build, which contains no frame generation at all.
    com.armsx2.ui.common.LsfgEmulationCard(
        enabled = settings.graphics.lsfgEnabled,
        multiplier = settings.graphics.lsfgMultiplier,
        dllPath = settings.graphics.lsfgDllPath,
        performance = settings.graphics.lsfgPerformance,
        fp16 = settings.graphics.lsfgFp16,
        flowScale = settings.graphics.lsfgFlowScale,
        targetRate = settings.graphics.lsfgTargetRate,
    ) { on, mult, dll, perf, flow, target, half ->
        viewModel.updateSettings {
            it.copy(
                graphics = it.graphics.copy(
                    lsfgEnabled = on,
                    lsfgMultiplier = mult,
                    lsfgDllPath = dll,
                    lsfgPerformance = perf,
                    lsfgFp16 = half,
                    lsfgFlowScale = flow,
                    lsfgTargetRate = target,
                ),
            )
        }
    }
    SectionCard(str("tab.recompiler")) {
        MenuSwitchRow("EE (R5900)", settings.cpu.recEE, field = "recEE") { value -> viewModel.updateSettings { it.copy(cpu = it.cpu.copy(recEE = value)) } }
        Spacer(Modifier.height(6.dp))
        MenuSwitchRow("IOP (R3000)", settings.cpu.recIOP, field = "recIOP") { value -> viewModel.updateSettings { it.copy(cpu = it.cpu.copy(recIOP = value)) } }
        Spacer(Modifier.height(6.dp))
        MenuSwitchRow("VU0", settings.cpu.recVU0, field = "recVU0") { value -> viewModel.updateSettings { it.copy(cpu = it.cpu.copy(recVU0 = value)) } }
        Spacer(Modifier.height(6.dp))
        MenuSwitchRow("VU1", settings.cpu.recVU1, field = "recVU1") { value -> viewModel.updateSettings { it.copy(cpu = it.cpu.copy(recVU1 = value)) } }
        Spacer(Modifier.height(6.dp))
        MenuSwitchRow("Fastmem", settings.cpu.enableFastmem, field = "enableFastmem") { value -> viewModel.updateSettings { it.copy(cpu = it.cpu.copy(enableFastmem = value)) } }
    }
    SectionCard(str("tab.overlay")) {
        MenuSwitchRow(str("overlay.toggle.fps"), settings.osd.osdShowFps, field = "osdShowFps") { value ->
            viewModel.updateSettings { it.copy(osd = it.osd.copy(osdShowFps = value)) }
        }
        Spacer(Modifier.height(6.dp))
        MenuSwitchRow(str("overlay.toggle.emulationSpeed"), settings.osd.osdShowSpeed, field = "osdShowSpeed") { value ->
            viewModel.updateSettings { it.copy(osd = it.osd.copy(osdShowSpeed = value)) }
        }
        Spacer(Modifier.height(6.dp))
        MenuSwitchRow(str("overlay.toggle.cpuUsage"), settings.osd.osdShowCpu, field = "osdShowCpu") { value ->
            viewModel.updateSettings { it.copy(osd = it.osd.copy(osdShowCpu = value)) }
        }
        Spacer(Modifier.height(6.dp))
        MenuSwitchRow(str("overlay.toggle.gpuUsage"), settings.osd.osdShowGpu, field = "osdShowGpu") { value ->
            viewModel.updateSettings { it.copy(osd = it.osd.copy(osdShowGpu = value)) }
        }
        Spacer(Modifier.height(6.dp))
        MenuSwitchRow(str("overlay.toggle.internalResolution"), settings.osd.osdShowResolution, field = "osdShowResolution") { value ->
            viewModel.updateSettings { it.copy(osd = it.osd.copy(osdShowResolution = value)) }
        }
        Spacer(Modifier.height(6.dp))
        MenuSwitchRow(str("overlay.toggle.onScreenNotifications"), settings.osd.osdShowMessages, field = "osdShowMessages") { value ->
            viewModel.updateSettings { it.copy(osd = it.osd.copy(osdShowMessages = value)) }
        }
    }
}

@Composable
private fun ControlsPane(state: EmulationMenuUiState, viewModel: EmulationMenuViewModel) {
    // The persisted on-screen controls setting itself, the same value All Settings > Controls
    // edits, with a button for every choice. This row used to flip a temporary flag that the next
    // screen touch undid, and after that to step through the choices one tap at a time.
    val visibilityMode = TouchControls.visibilityMode.intValue
    val gamepadAttached = TouchControls.gamepadConnected.value
    SectionCard(str("pad.onScreenControls.label")) {
        HorizontalOptionRow(
            options = listOf(
                TouchControls.VISIBILITY_AUTO to str("backend.renderer.auto"),
                TouchControls.VISIBILITY_ALWAYS to str("pad.onScreenControls.always"),
                TouchControls.VISIBILITY_OFF to str("setup.toggle.off"),
                TouchControls.CHOICE_AUTO_HIDE to str("pad.onScreenControls.autoHide"),
            ),
            selected = TouchControls.visibilityChoice(),
            keyPrefix = "onscreen",
            onSelect = TouchControls::chooseVisibility,
        )
        // Auto and Auto-hide change by themselves, so say what they are doing right now.
        // Off a handheld, Auto goes by the last button press, which no line here can state.
        val status = when {
            visibilityMode == TouchControls.VISIBILITY_AUTO && !TouchControls.autoFollowsGamepad -> null
            visibilityMode == TouchControls.VISIBILITY_AUTO && gamepadAttached ->
                str("pad.onScreenControls.nowHidden")
            visibilityMode == TouchControls.VISIBILITY_AUTO -> str("pad.onScreenControls.nowShown")
            visibilityMode in 1..10 -> str("pad.onScreenControls.hidesAfter").format(visibilityMode)
            else -> null
        }
        if (status != null) {
            Spacer(Modifier.height(6.dp))
            Text(status, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
    MenuSwitchRow(
        title = str("pad.rumble.label"),
        checked = state.rumbleEnabled,
        onCheckedChange = viewModel::setRumble,
    )
    // Vibration Strength — the same global 0-200% haptic multiplier as All Settings ›
    // Controls, reachable here in-game. Local state drives the live update since it's a
    // plain pref (not part of EmulationMenuUiState).
    var haptic by remember { mutableStateOf(com.armsx2.input.ControllerMappings.hapticIntensity()) }
    com.armsx2.ui.settings.IntSliderRow(
        label = str("pad.hapticStrength.label"),
        value = haptic,
        min = 0,
        max = 200,
        description = str("pad.hapticStrength.description"),
        valueFormatter = { if (it == 0) "Off" else "${it}%" },
        onChange = { haptic = it; com.armsx2.input.ControllerMappings.setHapticIntensity(it) },
    )
    MenuSwitchRow(str("pad.multitap.label"), state.multitapEnabled, onCheckedChange = viewModel::setMultitap)
    MenuSwitchRow(str("network.emulateUsbKeyboard"), state.settings.system.usbKeyboard, field = "usbKeyboard") {
        viewModel.updateSettings { current -> current.copy(system = current.system.copy(usbKeyboard = it)) }
    }

    // Gesture control, in-game. Worth having here rather than only in All Settings: the swipe
    // distance and the Tap/Hold choice are things you only discover the right value for while
    // actually playing, and walking out to the settings tree to nudge them loses the moment.
    // Local state, like the haptic slider above — these are plain prefs, not part of the ui state.
    var gestureOn by remember { mutableStateOf(TouchControls.gestureEnabled.value) }
    MenuSwitchRow(str("pad.gesture.enable.label"), gestureOn) {
        gestureOn = it
        TouchControls.setGestureEnabled(it)
    }
    if (gestureOn) {
        var swipeSens by remember { mutableStateOf((TouchControls.gestureSwipeSensitivity.floatValue * 100f).toInt()) }
        com.armsx2.ui.settings.IntSliderRow(
            label = str("pad.gesture.sensitivity.label"),
            value = swipeSens,
            min = 5,
            max = 60,
            description = str("pad.gesture.sensitivity.description"),
            valueFormatter = { "${it}%" },
            onChange = { swipeSens = it; TouchControls.setGestureSensitivity(it / 100f) },
        )
        var holdMode by remember { mutableStateOf(TouchControls.gestureDoubleTapHold.value) }
        HorizontalOptions(
            title = str("pad.gesture.doubleTapMode.label"),
            options = listOf(
                0 to str("pad.gesture.doubleTapMode.tap"),
                1 to str("pad.gesture.doubleTapMode.hold"),
            ),
            selected = if (holdMode) 1 else 0,
            onSelect = { holdMode = it == 1; TouchControls.setGestureDoubleTapHold(holdMode) },
        )
        // The four swipe/double-tap ASSIGNMENTS stay in All Settings — six button pickers would
        // swamp this pane, and you set them once rather than mid-session.
    }
    CompactAction(str("pad.controllerMapping"), "⌁", Modifier.fillMaxWidth(), viewModel::openControlsManager)
    Spacer(Modifier.height(6.dp))
    CompactAction(str("pad.editTouchLayout"), "✥", Modifier.fillMaxWidth(), viewModel::editTouchControls)
    Spacer(Modifier.height(6.dp))
    // Sits with the touch layout because it's the same job: what the on-screen pad LOOKS
    // like, right after where it's laid out. Full-screen like Controller mapping.
    CompactAction(str("tab.skins"), "◈", Modifier.fillMaxWidth(), viewModel::openSkins)
    Spacer(Modifier.height(6.dp))
    // Hotkeys, under Skins: All Settings' Hotkeys page, opened straight over the game.
    CompactAction(str("tab.hotkeys"), "⌘", Modifier.fillMaxWidth(), viewModel::openHotkeys)
    // Analog sticks in-game: swap/invert per stick, deadzone and feel. Requested because some
    // games ship no invert option of their own, so changing it meant leaving the game for All
    // Settings mid-session (Sizor). Global scope, matching the rumble/multitap toggles above.
    run {
        val stickPlayer = remember { androidx.compose.runtime.mutableIntStateOf(0) }
        val stickRefresh = remember { androidx.compose.runtime.mutableIntStateOf(0) }
        com.armsx2.ui.settings.AnalogSticksSection(stickPlayer, stickRefresh)
    }
    // Motion / gyroscope controls in-game (mode, sensitivity, smoothing, invert). Global scope
    // to match the rumble/multitap toggles above; the per-game scope lives in All Settings › Controls.
    com.armsx2.ui.settings.GyroSection()
    // Macros — edit each M1-M4 button set here in-game too (physical-trigger binding stays
    // in All Settings › Controls, which hosts the key-capture listener).
    com.armsx2.ui.settings.MacrosSection()
    com.armsx2.arcade.Arcade.sessionGameId.value?.let { com.armsx2.ui.settings.ArcadeControlsSection(it, pickGame = false) }
}

@Composable
private fun OptionsPane(state: EmulationMenuUiState, viewModel: EmulationMenuViewModel) {
    val settings = state.settings
    // Item 3: gateway to the full per-game settings (all categories the compact menu omits:
    // OSD, Skins, Audio, Hotkeys, Network, Recompiler, ...).
    CompactAction(str("action.allSettings"), "⚙", Modifier.fillMaxWidth(), viewModel::openFullSettings)
    Spacer(Modifier.height(6.dp))
    // In-game access to the manager screens (the library drawer's Memory Cards /
    // Patches & Cheats / Controller mapping) — open over the paused game.
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        CompactAction(str("memcard.title"), "▤", Modifier.weight(1f), viewModel::openMemcard)
        CompactAction(str("patches.dialog.patchesAndCheats"), "✦", Modifier.weight(1f), viewModel::openPatches)
    }
    // The texture pack manager moved to the Renderer page, under the resolution. Its glyph,
    // "▣", is one already proven to render in the shipped font -- "▩" (U+25A9) and "⏻" (U+23FB)
    // come out as tofu boxes on device.
    Spacer(Modifier.height(6.dp))
    // Volume and Mute: the same two settings as All Settings › Audio. Both apply instantly
    // (applyTo's direct setters).
    com.armsx2.ui.settings.IntSliderRow(
        label = str("audio.volume.label"),
        value = settings.audio.audioVolume.coerceIn(0, 150),
        min = 0,
        max = 150,
        valueFormatter = { "$it%" },
        field = "audioVolume",
        onChange = viewModel::setVolume,
    )
    MenuSwitchRow(str("audio.mute.label"), settings.audio.audioMuted, field = "audioMuted") {
        viewModel.updateSettings { current -> current.copy(audio = current.audio.copy(audioMuted = it)) }
    }
    MenuSwitchRow(str("patches.enablePatches.label"), settings.emuCore.enablePatches, field = "enablePatches") {
        viewModel.updateSettings { current -> current.copy(emuCore = current.emuCore.copy(enablePatches = it)) }
    }
    MenuSwitchRow(
        if (state.hardcore) str("patches.cheats.labelHardcore") else str("patches.cheats.label"),
        settings.emuCore.enableCheats && !state.hardcore,
        enabled = !state.hardcore,
        field = "enableCheats",
    ) {
        viewModel.updateSettings { current -> current.copy(emuCore = current.emuCore.copy(enableCheats = it)) }
    }
    MenuSwitchRow(str("patches.widescreen.label"), settings.emuCore.enableWideScreenPatches, field = "enableWideScreenPatches") {
        viewModel.updateSettings { current -> current.copy(emuCore = current.emuCore.copy(enableWideScreenPatches = it)) }
    }
    MenuSwitchRow(str("patches.noInterlacing.label"), settings.emuCore.enableNoInterlacingPatches, field = "enableNoInterlacingPatches") {
        viewModel.updateSettings { current -> current.copy(emuCore = current.emuCore.copy(enableNoInterlacingPatches = it)) }
    }
    MenuSwitchRow(str("perf.fix.skipBios"), settings.emuCore.enableFastBoot, field = "enableFastBoot") {
        viewModel.updateSettings { current -> current.copy(emuCore = current.emuCore.copy(enableFastBoot = it)) }
    }
    MenuSwitchRow(str("perf.fix.gamedbFixes"), settings.emuCore.enableGameFixes, field = "enableGameFixes") {
        viewModel.updateSettings { current -> current.copy(emuCore = current.emuCore.copy(enableGameFixes = it)) }
    }
    MenuSwitchRow(str("perf.fix.skipMpeg"), settings.emuCore.gamefixSkipMpeg, field = "gamefixSkipMpeg") {
        viewModel.updateSettings { current -> current.copy(emuCore = current.emuCore.copy(enableGameFixes = true, gamefixSkipMpeg = it)) }
    }
    MenuSwitchRow(str("perf.fix.fmvSoftware"), settings.emuCore.gamefixSoftwareRendererFmv, field = "gamefixSoftwareRendererFmv") {
        viewModel.updateSettings { current -> current.copy(emuCore = current.emuCore.copy(enableGameFixes = true, gamefixSoftwareRendererFmv = it)) }
    }
    MenuSwitchRow(str("perf.fix.eeTiming"), settings.emuCore.gamefixEETiming, field = "gamefixEETiming") {
        viewModel.updateSettings { current -> current.copy(emuCore = current.emuCore.copy(enableGameFixes = true, gamefixEETiming = it)) }
    }
    MenuSwitchRow(str("perf.fix.instantDma"), settings.emuCore.gamefixInstantDma, field = "gamefixInstantDma") {
        viewModel.updateSettings { current -> current.copy(emuCore = current.emuCore.copy(enableGameFixes = true, gamefixInstantDma = it)) }
    }
    MenuSwitchRow(str("perf.fix.blitFps"), settings.emuCore.gamefixBlitInternalFps, field = "gamefixBlitInternalFps") {
        viewModel.updateSettings { current -> current.copy(emuCore = current.emuCore.copy(enableGameFixes = true, gamefixBlitInternalFps = it)) }
    }
    MenuSwitchRow(str("perf.fix.vuAddSub"), settings.emuCore.gamefixVuAddSub, field = "gamefixVuAddSub") {
        viewModel.updateSettings { current -> current.copy(emuCore = current.emuCore.copy(enableGameFixes = true, gamefixVuAddSub = it)) }
    }
    MenuSwitchRow(str("perf.fix.vuSync"), settings.emuCore.gamefixVuSync, field = "gamefixVuSync") {
        viewModel.updateSettings { current -> current.copy(emuCore = current.emuCore.copy(enableGameFixes = true, gamefixVuSync = it)) }
    }
}

@Composable
private fun AchievementsPane(state: EmulationMenuUiState, viewModel: EmulationMenuViewModel) {
    // RetroAchievements on or off, saved in the menu's scope: for this game when one is running,
    // which is the point -- it can be off globally and on for the games you want it in. The core
    // starts or stops it live (Achievements::UpdateSettings), no restart.
    MenuSwitchRow(
        str(if (com.armsx2.ui.InGameOverlay.settingsScope.value == com.armsx2.config.SettingsScope.Game)
            "ra.enable.thisGame" else "ra.enable.label"),
        state.settings.emuCore.achievements.enabled,
        field = "achievementsEnabled",
    ) { on -> viewModel.updateSettings { it.copy(emuCore = it.emuCore.copy(achievements = it.emuCore.achievements.copy(enabled = on))) } }
    Spacer(Modifier.height(4.dp))
    // Gateway to the full RetroAchievements screen (unlock list + presentation options).
    CompactAction(str("ra.viewAchievements"), "★", Modifier.fillMaxWidth(), viewModel::openAchievements)
    Spacer(Modifier.height(4.dp))
    SectionCard("RetroAchievements") {
        // Signed-in account: avatar + name + both point totals (hardcore / softcore).
        if (state.raUserName.isNotBlank()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (state.raAvatarUrl.isNotBlank()) {
                    AsyncImage(
                        state.raAvatarUrl,
                        state.raUserName,
                        Modifier.size(46.dp).clip(CircleShape),
                        contentScale = ContentScale.Crop,
                    )
                    Spacer(Modifier.width(12.dp))
                }
                Column(Modifier.weight(1f)) {
                    Text(
                        state.raUserName,
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "${state.raScore} HC",
                            style = MaterialTheme.typography.bodySmall,
                            color = com.armsx2.ui.theme.Danger,
                        )
                        Text(
                            "  ·  ${state.raSoftcoreScore} SC",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }
        Text(
            state.achievementSummary,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(8.dp))
        MenuSwitchRow(
            str(if (state.hardcore) "ra.mode.hardcore" else "ra.mode.casual"),
            state.hardcore,
            onCheckedChange = { viewModel.requestToggleHardcore() },
        )
    }
    // Inline unlock list, right below the hardcore toggle — no need to open the full
    // screen (it's still available via the button above).
    state.achievements.forEach { item -> InGameAchievementRow(item) }
}

@Composable
private fun InGameAchievementRow(item: AchievementItem) {
    Surface(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = if (item.unlocked) MaterialTheme.colorScheme.primaryContainer
        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.42f),
        border = BorderStroke(
            1.dp,
            if (item.unlocked) MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
            else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
        ),
    ) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            if (item.iconUrl.isNotBlank()) {
                AsyncImage(
                    item.iconUrl,
                    item.title,
                    Modifier.size(40.dp).clip(RoundedCornerShape(9.dp)),
                    contentScale = ContentScale.Crop,
                )
            } else {
                Box(
                    Modifier.size(40.dp).clip(RoundedCornerShape(9.dp))
                        .background(MaterialTheme.colorScheme.surface),
                    contentAlignment = Alignment.Center,
                ) { Text(if (item.unlocked) "★" else "☆") }
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(item.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(item.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
                if (item.progress.isNotBlank()) {
                    Text(item.progress, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                }
            }
            Spacer(Modifier.width(8.dp))
            // Flag missables in-game — the actionable warning while you're actually playing.
            // Progression/Win badges are left to the full achievements screen to avoid clutter here.
            if (item.type == 1) {
                StatusChip(str("ra.typeChip.missable"), Color(0xFFF5A623))
                Spacer(Modifier.width(8.dp))
            }
            Text(
                "${item.points}",
                style = MaterialTheme.typography.labelMedium,
                color = if (item.unlocked) Success else MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.Bold,
            )
        }
    }
}

@Composable
private fun HardcoreBadge() {
    // Firebrick red to match the old UI's hardcore pill (theme Danger reads pink here).
    Surface(shape = RoundedCornerShape(6.dp), color = Color(0xFFB22222)) {
        Text(
            "HC",
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
            color = Color.White,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
        )
    }
}

/**
 * The arcade cabinet's own buttons, while an arcade game runs: coins, Service and the Test switch.
 * Each goes back to the game, which only sees a press it is running for.
 */
@Composable
private fun arcadeActions(viewModel: EmulationMenuViewModel): List<MenuAction> {
    if (com.armsx2.arcade.Arcade.sessionMode.intValue < 0) return emptyList()
    return listOf(
        MenuAction(str("arcade.coin.p1"), str("arcade.coin.p1.detail"), "¢", null) {
            com.armsx2.arcade.Arcade.insertCoin(0)
            viewModel.resume()
        },
        MenuAction(str("arcade.coin.p2"), str("arcade.coin.p2.detail"), "¢", null) {
            com.armsx2.arcade.Arcade.insertCoin(1)
            viewModel.resume()
        },
        MenuAction(str("arcade.service"), str("arcade.service.detail"), "✚", null) {
            viewModel.resume()
            com.armsx2.arcade.Arcade.pressService()
        },
        MenuAction(str("arcade.test"), str("arcade.test.detail"), "⚙", null) {
            com.armsx2.arcade.Arcade.toggleTest()
            viewModel.resume()
        },
    )
}

private data class MenuAction(
    val title: String,
    val detail: String,
    val glyph: String,
    val accent: Color?,
    val action: () -> Unit,
)

@Composable
private fun ActionGrid(actions: List<MenuAction>) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        actions.forEachIndexed { index, item ->
            val id = "pause.action.$index"
            // The registry is the ONE source of truth for which row is selected. The tint used
            // to come from a separate index in the view model that advanced only when a row was
            // ACTIVATED, while the D-pad moved the registry — so the menu drew one selection and
            // moved another, and the row you were pointing at was never the one lit up.
            val active = com.armsx2.ui.settings.SettingsControllerNav.isSelected(id)
            Surface(
                onClick = item.action,
                modifier = Modifier
                    .fillMaxWidth()
                    .controllerFocusable(id, onConfirm = item.action),
                shape = RoundedCornerShape(16.dp),
                color = if (active) MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)
                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.48f),
                border = BorderStroke(
                    1.dp,
                    if (active) MaterialTheme.colorScheme.primary.copy(alpha = 0.72f)
                    else MaterialTheme.colorScheme.outline.copy(alpha = 0.34f),
                ),
            ) {
                Row(Modifier.padding(horizontal = 13.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        item.glyph,
                        color = item.accent ?: MaterialTheme.colorScheme.primary,
                        fontSize = 19.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.width(30.dp),
                    )
                    Column(Modifier.weight(1f)) {
                        Text(item.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                        if (item.detail.isNotBlank()) {
                            Text(
                                item.detail,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
internal fun SectionCard(title: String, field: String? = null, content: @Composable ColumnScope.() -> Unit) {
    val tint = com.armsx2.ui.settings.rowTint(field, fillAlpha = 0.42f, outlineAlpha = 0.34f)
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(17.dp),
        color = tint.container,
        border = BorderStroke(1.dp, tint.border),
    ) {
        Column(Modifier.padding(13.dp)) {
            Text(
                title,
                modifier = Modifier.overrideMarker(tint, MaterialTheme.typography.titleSmall.lineHeight),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
            )
            Spacer(Modifier.height(8.dp))
            content()
        }
    }
}

@Composable
private fun <T> HorizontalOptions(
    title: String,
    options: List<Pair<T, String>>,
    selected: T,
    onSelect: (T) -> Unit,
    field: String? = null,
) {
    SectionCard(title, field) {
        HorizontalOptionRow(options, selected, keyPrefix = title, onSelect = onSelect)
    }
}

// Free-choice framerate slider (20–120 Hz) instead of a couple of fixed chips.
// The default (59.94 / 50) is kept exactly, and the 60/50 stops snap back to
// those exact PS2 rates (canonicalFramerate) so the true default is always
// recoverable; every other stop is whole Hz for easy targets (72/90/120).
@Composable
private fun FramerateSlider(title: String, value: Float, onValue: (Float) -> Unit, field: String? = null) {
    SectionCard(title, field) {
        Column(
            Modifier.fillMaxWidth().controllerFocusable(
                "pause.framerate.$title",
                onLeft = { onValue(canonicalFramerate((Math.round(value) - 1).coerceAtLeast(20))) },
                onRight = { onValue(canonicalFramerate((Math.round(value) + 1).coerceAtMost(120))) },
            ),
        ) {
            val label = if (value % 1f == 0f) "${value.toInt()} Hz" else "%.2f Hz".format(value)
            Text(label, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            Slider(
                value = value.coerceIn(20f, 120f),
                onValueChange = { onValue(canonicalFramerate(Math.round(it))) },
                valueRange = 20f..120f,
            )
        }
    }
}

// The PS2's true NTSC/PAL rates are 59.94/50.00 Hz; the integer slider stops at
// 60/50 map back to those exact defaults so the canonical rate stays recoverable
// (dragging otherwise snaps to whole Hz and loses 59.94 forever).
private fun canonicalFramerate(hz: Int): Float = when (hz) {
    60 -> 59.94f
    50 -> 50.00f
    else -> hz.toFloat()
}

@Composable
private fun <T> HorizontalOptionRow(
    options: List<Pair<T, String>>,
    selected: T,
    keyPrefix: String,
    onSelect: (T) -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .bleedHorizontal(13.dp)
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 13.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        options.forEach { (value, label) ->
            OptionChip(label, selected == value, controllerId = "pause.$keyPrefix.$label") { onSelect(value) }
        }
    }
}

@Composable
private fun OptionChip(label: String, selected: Boolean, controllerId: String? = null, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        modifier = Modifier.controllerFocusable(controllerId, RoundedCornerShape(12.dp), onConfirm = onClick),
        shape = RoundedCornerShape(12.dp),
        color = if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.17f)
        else MaterialTheme.colorScheme.surface,
        border = BorderStroke(
            1.dp,
            if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.38f),
        ),
    ) {
        Text(
            label,
            modifier = Modifier.padding(horizontal = 13.dp, vertical = 9.dp),
            color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            maxLines = 2,
        )
    }
}

@Composable
private fun MenuSwitchRow(
    title: String,
    checked: Boolean,
    enabled: Boolean = true,
    description: String? = null,
    field: String? = null,
    onCheckedChange: (Boolean) -> Unit,
) {
    val tint = com.armsx2.ui.settings.rowTint(field, fillAlpha = if (enabled) 0.42f else 0.24f, outlineAlpha = 0.34f)
    Surface(
        onClick = { if (enabled) onCheckedChange(!checked) },
        modifier = Modifier
            .fillMaxWidth()
            .controllerFocusable(
                "pause.switch.$title",
                onConfirm = { if (enabled) onCheckedChange(!checked) },
            ),
        enabled = enabled,
        shape = RoundedCornerShape(16.dp),
        color = tint.container,
        border = BorderStroke(1.dp, tint.border),
    ) {
        Row(
            Modifier.padding(horizontal = 13.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    title,
                    modifier = Modifier.overrideMarker(tint, MaterialTheme.typography.titleSmall.lineHeight),
                    style = MaterialTheme.typography.titleSmall,
                    color = if (enabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                )
                if (description != null) {
                    Text(
                        description,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 3,
                    )
                }
            }
            Spacer(Modifier.width(10.dp))
            Switch(checked = checked, onCheckedChange = if (enabled) onCheckedChange else null)
        }
    }
}

/** Label + current value, cycled in place: tap/confirm and Right advance, Left steps back.
 *  The compact menu has no picker of its own and a segmented control doesn't fit its width,
 *  so multi-option settings cycle rather than expand. */
@Composable
private fun MenuCycleRow(
    title: String,
    valueLabel: String,
    field: String? = null,
    onStep: (Int) -> Unit,
) {
    val tint = com.armsx2.ui.settings.rowTint(field, fillAlpha = 0.42f, outlineAlpha = 0.34f)
    Surface(
        onClick = { onStep(1) },
        modifier = Modifier
            .fillMaxWidth()
            .controllerFocusable(
                "pause.cycle.$title",
                onConfirm = { onStep(1) },
                onLeft = { onStep(-1) },
                onRight = { onStep(1) },
            ),
        shape = RoundedCornerShape(16.dp),
        color = tint.container,
        border = BorderStroke(1.dp, tint.border),
    ) {
        Row(
            Modifier.padding(horizontal = 13.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                title,
                modifier = Modifier.weight(1f).overrideMarker(tint, MaterialTheme.typography.titleSmall.lineHeight),
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 2,
            )
            Spacer(Modifier.width(10.dp))
            Text(
                valueLabel,
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary,
            )
        }
    }
}

@Composable
private fun CompactAction(title: String, glyph: String, modifier: Modifier, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        modifier = modifier.controllerFocusable("pause.compact.$title", onConfirm = onClick),
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.42f)),
    ) {
        Row(
            Modifier.padding(horizontal = 12.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(glyph, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            Text(title, style = MaterialTheme.typography.labelLarge, maxLines = 2)
        }
    }
}

private fun Modifier.bleedHorizontal(edge: androidx.compose.ui.unit.Dp): Modifier = layout { measurable, constraints ->
    val edgePx = edge.roundToPx()
    val expandedMin = (constraints.minWidth + edgePx * 2).coerceAtMost(constraints.maxWidth + edgePx * 2)
    val expandedMax = constraints.maxWidth + edgePx * 2
    val placeable = measurable.measure(
        constraints.copy(
            minWidth = expandedMin,
            maxWidth = expandedMax,
        ),
    )
    layout(constraints.maxWidth, placeable.height) {
        placeable.placeRelative(-edgePx, 0)
    }
}
