package com.armsx2.ui.common

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import com.armsx2.ui.theme.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.armsx2.CustomDriver
import com.armsx2.i18n.str
import com.armsx2.runtime.MainActivityRuntime
import com.armsx2.ui.InGameOverlay
import com.armsx2.ui.settings.controllerFocusable
import com.armsx2.ui.theme.Success
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Vulkan custom-driver manager: pick the system driver or an installed one, download
 * fresh builds from the bundled sources, import a local .zip, or delete an installed driver.
 * The download list is filtered to the device's GPU family ([CustomDriver.fetchRemote]): Turnip
 * and Adreno Tools packs on Adreno, the MaliSX2 packs on the Mali parts they support, the Exynos
 * packs on Xclipse. Self-contained (plain Material3)
 * so it drops into both the full Settings renderer tab and the in-game renderer pane.
 * Selecting a driver only takes effect on the next renderer init — the caller shows an
 * "Apply & Restart" affordance.
 */
@Composable
fun DriverManagerSection() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val installed = remember { mutableStateListOf<CustomDriver.InstalledDriver>().apply { addAll(CustomDriver.listInstalled(context)) } }
    var remote by remember { mutableStateOf<List<CustomDriver.RemoteDriver>?>(null) }
    var loadingRemote by remember { mutableStateOf(false) }
    var showRemote by remember { mutableStateOf(false) }
    var busyId by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    // str() is @Composable, so resolve the messages the coroutines set up-front.
    val installedMsg = str("backend.driver.installed")
    val importErr = str("backend.driver.importError")
    val fetchErr = str("backend.driver.fetchError")
    val installedOkMsg = str("backend.driver.installedOk")
    val importFailedMsg = str("backend.driver.importFailed")
    val downloadFailedMsg = str("backend.driver.downloadFailed")
    // Which source groups are expanded in the online list (collapsed by default).
    val expandedSources = remember { mutableStateMapOf<String, Boolean>() }

    fun refreshInstalled() {
        installed.clear()
        installed.addAll(CustomDriver.listInstalled(context))
    }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            busyId = "import"; message = null
            val d = withContext(Dispatchers.IO) { CustomDriver.installFromUri(context, uri) }
            busyId = null
            if (d != null) { refreshInstalled(); selectDriver(d.id); message = "$installedOkMsg ${d.name}" }
            else message = importFailedMsg
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        SectionTitle(str("backend.gpuDriver.label"), str("backend.gpuDriver.description"))

        // Eden-style hint: the detected GPU and the best custom-driver source for it. Adreno
        // maps to a tuned Turnip pack, a supported Mali to our MaliSX2; other GPUs (Xclipse,
        // PowerVR, an unsupported Mali) run the built-in system driver best. Probes the system
        // GL_RENDERER once (cached).
        val gpuModel = remember { com.armsx2.GpuInfo.rendererName() }
        val gpuRec = remember(gpuModel) { com.armsx2.GpuInfo.recommendation(gpuModel) }
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(str("backend.driver.gpuModel"), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(gpuModel ?: str("backend.driver.gpuUnknown"), style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(str("backend.driver.recommended"), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(gpuRec?.sourceLabel ?: str("backend.driver.recommendSystem"), style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                }
                gpuRec?.reason?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
        }

        // The driver this scope actually runs with. A per-game pick that has since been deleted
        // follows the global driver at boot (CustomDriver.effectiveId), so show that one.
        // Re-read whenever the settings change: in global scope a save here changes the global id.
        val globalDriverId = remember(InGameOverlay.settingsState.value) { com.armsx2.config.ConfigStore.loadGlobal().output.customDriverId }
        val effectiveId = CustomDriver.effectiveId(
            InGameOverlay.settingsState.value.output.customDriverId, globalDriverId, installed.map { it.id })
        DriverRow(
            controllerId = "driver.system",
            title = str("backend.driver.systemVulkan"),
            subtitle = str("renderer.orientation.device"),
            selected = effectiveId == null,
            onClick = { selectDriver(null) },
        )
        installed.forEach { driver ->
            DriverRow(
                controllerId = "driver.${driver.id}",
                title = driver.name,
                subtitle = listOf(driver.vendor, driver.version).filter(String::isNotBlank).joinToString(" · ")
                    .ifBlank { str("backend.driver.installed") },
                selected = effectiveId == driver.id,
                onClick = { selectDriver(driver.id) },
                onDelete = {
                    CustomDriver.delete(driver)
                    refreshInstalled()
                },
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                shape = RoundedCornerShape(13.dp),
                modifier = Modifier.controllerFocusable(
                    "driver.toggleDownloads",
                    RoundedCornerShape(13.dp),
                    onConfirm = {
                        showRemote = !showRemote
                        if (showRemote && remote == null && !loadingRemote) {
                            loadingRemote = true
                            scope.launch {
                                val r = withContext(Dispatchers.IO) { CustomDriver.fetchRemote(gpuModel) }
                                remote = r; loadingRemote = false
                            }
                        }
                    },
                ),
                onClick = {
                    showRemote = !showRemote
                    if (showRemote && remote == null && !loadingRemote) {
                        loadingRemote = true
                        scope.launch {
                            val r = withContext(Dispatchers.IO) { CustomDriver.fetchRemote(gpuModel) }
                            remote = r; loadingRemote = false
                        }
                    }
                },
            ) { Text(if (showRemote) str("backend.driver.hideDownloads") else str("backend.driver.download")) }
            OutlinedButton(
                shape = RoundedCornerShape(13.dp),
                modifier = Modifier.controllerFocusable(
                    "driver.import",
                    RoundedCornerShape(13.dp),
                    onConfirm = { importLauncher.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) },
                ),
                onClick = { importLauncher.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) },
            ) { Text(str("backend.driver.import")) }
        }

        if (showRemote) {
            when {
                loadingRemote -> Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer8()
                    Text(str("backend.driver.fetching"), color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                remote.isNullOrEmpty() -> Text(str("backend.driver.none"), color = MaterialTheme.colorScheme.onSurfaceVariant)
                // Group the online drivers by source (K11MCH1 / MrPurple / StevenMXZ /
                // crueter…), each an expandable, controller-navigable section.
                else -> remote!!.groupBy { it.source }.forEach { (source, drivers) ->
                    val expanded = expandedSources[source] ?: false
                    DriverSourceGroup(
                        source = source,
                        count = drivers.size,
                        expanded = expanded,
                        onToggle = { expandedSources[source] = !expanded },
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            drivers.forEach { rd ->
                                RemoteDriverRow(
                                    controllerId = "driver.remote.${rd.id}",
                                    title = rd.title.ifBlank { rd.assetName },
                                    subtitle = listOf(rd.source, rd.tagName).filter(String::isNotBlank).joinToString(" · "),
                                    busy = busyId == rd.id,
                                    onDownload = {
                                        scope.launch {
                                            busyId = rd.id; message = null
                                            val d = withContext(Dispatchers.IO) { CustomDriver.download(context, rd) }
                                            busyId = null
                                            if (d != null) { refreshInstalled(); selectDriver(d.id); message = "$installedOkMsg ${d.name}" }
                                            else message = downloadFailedMsg
                                        }
                                    },
                                )
                            }
                        }
                    }
                }
            }
        }

        if (busyId == "import") Text(str("backend.driver.installing"), color = MaterialTheme.colorScheme.onSurfaceVariant)
        message?.let { Text(it, color = MaterialTheme.colorScheme.primary) }

        // Only an installed driver reads these, so they appear once there is one.
        if (installed.isNotEmpty()) TurnipOptions()
    }
}

/**
 * Turnip's environment options (#719), after Eden's Freedreno settings page: the UBWC flag hint
 * recent builds need on Snapdragon 8 Gen 2, and free NAME=value lines for anything else. Global
 * rather than per game, since they describe the device's driver, not a title. Applied by
 * [CustomDriver.applyDriverEnv] at the next game start.
 */
@Composable
private fun TurnipOptions() {
    var ubwcHint by remember { mutableStateOf(CustomDriver.ubwcFlagHint()) }
    var envText by remember { mutableStateOf(CustomDriver.driverEnvText()) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        SectionTitle(str("backend.turnip.label"), str("backend.turnip.description"))
        SettingSwitchRow(
            title = str("backend.turnip.ubwcHint"),
            description = str("backend.turnip.ubwcHint.desc"),
            checked = ubwcHint,
            onCheckedChange = { ubwcHint = it; CustomDriver.setUbwcFlagHint(it) },
        )
        OutlinedTextField(
            value = envText,
            onValueChange = { envText = it; CustomDriver.setDriverEnvText(it) },
            label = { Text(str("backend.turnip.env")) },
            placeholder = { Text("TU_DEBUG=sysmem") },
            supportingText = { Text(str("backend.turnip.env.desc")) },
            minLines = 2,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

/**
 * OpenGL "custom driver" picker — the GL analogue of the Vulkan [DriverManagerSection].
 * The one option is ANGLE (Google's GLES-on-Vulkan translator), which fixes the OpenGL
 * renderer on devices whose native GL driver is weak or buggy (most non-Adreno GPUs —
 * Mali / Xclipse / PowerVR). Selecting toggles EmuCore/GS/AndroidUseAngleOpenGL; it
 * takes effect on the next renderer init (the caller shows an Apply & Restart button).
 * Shown in place of the Vulkan driver list when the OpenGL renderer is selected, so the
 * driver picker always matches the chosen graphics API. Presentation only — the caller
 * wires [useAngle]/[onSelect] to its own settings tier (global or per-game).
 */
@Composable
fun AngleDriverSection(useAngle: Boolean, onSelect: (Boolean) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        SectionTitle(str("backend.glDriver.label"), str("backend.glDriver.description"))
        DriverRow(
            controllerId = "gldriver.system",
            title = str("backend.driver.systemGl"),
            subtitle = str("renderer.orientation.device"),
            selected = !useAngle,
            onClick = { onSelect(false) },
        )
        DriverRow(
            controllerId = "gldriver.angle",
            title = "ANGLE",
            subtitle = str("backend.driver.angleSubtitle"),
            selected = useAngle,
            onClick = { onSelect(true) },
        )
    }
}

@Composable
private fun DriverSourceGroup(
    source: String,
    count: Int,
    expanded: Boolean,
    onToggle: () -> Unit,
    content: @Composable () -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Surface(
            onClick = onToggle,
            modifier = Modifier.fillMaxWidth()
                .controllerFocusable("driver.group.$source", RoundedCornerShape(14.dp), onConfirm = onToggle),
            shape = RoundedCornerShape(14.dp),
            color = MaterialTheme.colorScheme.surfaceVariant,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
        ) {
            Row(Modifier.padding(horizontal = 14.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(if (expanded) "▾" else "▸", color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(10.dp))
                Text(source, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("$count", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (expanded) content()
    }
}

@Composable
private fun DriverRow(
    controllerId: String,
    title: String,
    subtitle: String,
    selected: Boolean,
    onClick: () -> Unit,
    onDelete: (() -> Unit)? = null,
) {
    Surface(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().controllerFocusable(controllerId, RoundedCornerShape(16.dp), onConfirm = onClick),
        shape = RoundedCornerShape(16.dp),
        color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
        border = BorderStroke(1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)),
    ) {
        Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (selected) StatusChip(str("backend.driver.active"), Success)
            if (onDelete != null) TextButton(onClick = onDelete, modifier = Modifier.controllerFocusable("$controllerId.delete", onConfirm = onDelete)) { Text(str("action.delete"), color = MaterialTheme.colorScheme.error) }
        }
    }
}

@Composable
private fun RemoteDriverRow(controllerId: String, title: String, subtitle: String, busy: Boolean, onDownload: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.42f)),
    ) {
        Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (subtitle.isNotBlank()) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (busy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
            else OutlinedButton(onClick = onDownload, shape = RoundedCornerShape(12.dp), modifier = Modifier.controllerFocusable(controllerId, RoundedCornerShape(12.dp), onConfirm = onDownload)) { Text(str("backend.driver.get")) }
        }
    }
}

@Composable
private fun Spacer8() = androidx.compose.foundation.layout.Spacer(Modifier.width(10.dp))

private fun selectDriver(id: String?) {
    // UI mirror for the pre-launch baseline; the real driver load happens at the next
    // renderer (re)start via applyRendererPrefs. Persist scope-aware (per-game when the
    // settings scope is Game) so a title can pin the driver it needs.
    MainActivityRuntime.customDriverId.value = id
    InGameOverlay.saveSettings(InGameOverlay.settingsState.value.copy(output = InGameOverlay.settingsState.value.output.copy(customDriverId = id ?: "")))
}
