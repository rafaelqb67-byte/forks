package com.armsx2.navigation

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.EaseIn
import androidx.compose.animation.core.EaseOut
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import com.armsx2.ui.theme.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import android.content.res.Configuration
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.armsx2.runtime.MainActivityRuntime
import com.armsx2.i18n.I18n
import com.armsx2.i18n.str
import com.armsx2.ui.common.ArmsLogo
import com.armsx2.ui.common.StatusChip
import com.armsx2.ui.settings.controllerFocusable

// Warm gold for the RetroAchievements trophy, matching the old (refresh) UI's
// gold trophy rather than the flat monochrome nav glyphs.
private val TrophyGold = Color(0xFFFFC93C)

// Exit is the only row here that ends your session, so it gets the standard power-red rather
// than the neutral row tint — the same reason the trophy keeps its gold.
private val ExitRed = Color(0xFFE60012)

// Community/project links for the drawer's About section. Plain https on purpose: Android App
// Links hand these to the Discord/GitHub apps when they're installed and fall back to the
// browser when they aren't, so there's no app-specific scheme to special-case.
/** Our Discord invite. Also where new texture packs are sent (TextureOnlineSection). */
internal const val DiscordUrl = "https://discord.gg/2Tynvwhc4A"
private const val GithubUrl = "https://github.com/ARMSX2/ARMSX2"
private const val WebsiteUrl = "https://armsx2.net/"

/**
 * Opens an external link, telling the user when nothing on the device can handle it.
 *
 * Deliberately NOT Compose's LocalUriHandler.openUri(): AndroidUriHandler catches
 * ActivityNotFoundException internally and rethrows it as IllegalArgumentException, so a
 * try/catch on the documented type catches nothing and a browser-less device takes an
 * uncaught crash instead of a Toast (the existing AboutScreen links have that hole).
 *
 * Equally deliberate: no resolveActivity()/queryIntentActivities() pre-check. Those ARE subject
 * to Android 11+ package-visibility filtering (we declare no <queries>), so a "can anything
 * handle this?" guard can read null for a link that would in fact open — turning a working row
 * into a silent no-op. startActivity() is NOT filtered, so launch it and catch the real miss.
 */
private fun openExternalUrl(context: Context, url: String) {
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    } catch (_: ActivityNotFoundException) {
        // Built outside composition, so I18n.get rather than str().
        Toast.makeText(context, I18n.get("about.openFailed"), Toast.LENGTH_LONG).show()
    }
}

private data class DrawerItem(
    val titleKey: String,
    val glyph: String,
    // A nav destination OR an action (onAction). Action rows (e.g. Boot BIOS) run onAction and
    // close the drawer instead of navigating to a screen.
    val destination: AppRoute? = null,
    val iconRes: Int? = null,
    // Null = tint the icon like the row's text. Only the trophy pins a fixed colour.
    val iconTint: Color? = null,
    // A full-colour picture drawn in the glyph's place and box, so it sits with the emoji rows around
    // it (the arcade logo among the managers).
    val glyphIcon: Int? = null,
    val onAction: (() -> Unit)? = null,
    // Overlay the live "friends online" count on this row's glyph. Only Friends uses it — the
    // point is to be visible from the drawer without opening the screen.
    val friendsBadge: Boolean = false,
)

@Composable
fun NavigationHub(
    visible: Boolean,
    selected: AppRoute,
    onDismiss: () -> Unit,
    onNavigate: (AppRoute) -> Unit,
) {
    BackHandler(enabled = visible, onBack = onDismiss)
    val scrimState = remember { MutableTransitionState(false) }
    val panelState = remember { MutableTransitionState(false) }
    LaunchedEffect(visible) {
        scrimState.targetState = visible
        panelState.targetState = visible
    }
    Box(Modifier.fillMaxSize()) {
        AnimatedVisibility(
            visibleState = scrimState,
            enter = fadeIn(tween(200, easing = EaseOut)),
            exit = fadeOut(tween(200, easing = EaseIn)),
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.62f))
                    .clickable(onClick = onDismiss),
            )
        }
        // Painel de grade que sobe de baixo (substitui a gaveta lateral).
        AnimatedVisibility(
            visibleState = panelState,
            enter = slideInVertically(tween(300, easing = EaseOut)) { it },
            exit = slideOutVertically(tween(220, easing = EaseIn)) { it },
            modifier = Modifier.align(Alignment.BottomCenter),
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.82f)
                    .widthIn(max = 920.dp),
                shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)),
                shadowElevation = 24.dp,
            ) {
                HubContent(selected, onNavigate, onDismiss)
            }
        }
    }
}

@Composable
private fun HubContent(selected: AppRoute, onNavigate: (AppRoute) -> Unit, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val exitConfirm = androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    if (exitConfirm.value) {
        com.armsx2.ui.common.ConfirmOverlay(
            title = str("games.exit.title"),
            message = str("games.exit.message"),
            confirmLabel = str("games.toolbar.exit"),
            idPrefix = "hub-exit",
            onConfirm = {
                exitConfirm.value = false
                MainActivityRuntime.exitApp()
            },
            onDismiss = { exitConfirm.value = false },
        )
    }
    // Intuitive glyphs that read as what they do — matching the in-game overlay's emoji-icon style
    // (the old box-drawing characters like ▦ ◉ ⌁ ✦ were unclear per tester feedback).
    val primary = listOf(
        DrawerItem("games.section.library", "🎮", AppRoute.Home),
        // Boot straight into the PS2 system BIOS with no disc — distinct from "BIOS Location"
        // below, which only points the emulator at your BIOS file.
        DrawerItem("bios.boot.title", "▶️", onAction = { MainActivityRuntime.startBios(); onDismiss() }),
        // Pick a file and run it, without it joining the library. Sits next to Boot BIOS because
        // both are "start something that is not a library entry".
        DrawerItem("action.launchGame", "📂", onAction = { MainActivityRuntime.promptLaunchGame(); onDismiss() }),
        DrawerItem("ra.title", "🏆", AppRoute.Achievements, iconRes = com.armsx2.R.drawable.ic_trophy,
            iconTint = TrophyGold),
        DrawerItem("action.settings", "⚙️", AppRoute.Settings()),
    )
    val managers = listOf(
        // Moved off the library overflow menu, which was its only entry point. Sits first, beside
        // BIOS Location: both answer "where are my files".
        DrawerItem("games.overflow.setup", "📂",
            onAction = { MainActivityRuntime.reopenSetup(); onDismiss() }),
        DrawerItem("setup.step.bios.title", "📀", AppRoute.BiosManager()),
        DrawerItem("memcard.title", "💾", AppRoute.MemoryCardManager()),
        DrawerItem("savestate.title.loadManage", "📥", AppRoute.SaveManager()),
        DrawerItem("tab.controls", "🕹️", AppRoute.ControllerManager),
        DrawerItem("patches.dialog.patchesAndCheats", "🪄", AppRoute.PatchManager),
        DrawerItem("renderer.section.texturePacks", "🖌️", AppRoute.TextureManager),
        // Namco System 246/256 arcade games: their folder, boot files, BIOS and imports.
        DrawerItem("arcade.title", "👾", AppRoute.Arcade, glyphIcon = com.armsx2.R.drawable.ic_arcade),
    )
    // Link-out rows: they reuse the existing onAction path (like Boot BIOS) rather than a
    // destination, so they leave the drawer via startActivity and close it behind them.
    val about = listOf(
        DrawerItem("about.discord", "💬", iconRes = com.armsx2.R.drawable.ic_discord,
            onAction = { openExternalUrl(context, DiscordUrl); onDismiss() }),
        DrawerItem("about.github", "🐙", iconRes = com.armsx2.R.drawable.ic_github,
            onAction = { openExternalUrl(context, GithubUrl); onDismiss() }),
        DrawerItem("about.website", "🌐", onAction = { openExternalUrl(context, WebsiteUrl); onDismiss() }),
        // In-app release notes. A destination rather than a link-out because the point is to read
        // what changed without leaving for a browser — the GitHub row above is still there for
        // anyone who wants the repo itself.
        DrawerItem("news.title", "📰", AppRoute.News),
        DrawerItem("friends.title", "👥", AppRoute.Friends, friendsBadge = true),
        DrawerItem("remoteplay.title", "📡", AppRoute.RemotePlay),
        // About left the settings tab strip: it is a read-only page, not a setting, and it sat in
        // the tab row costing a slot on every settings visit.
        DrawerItem("about.title", "ℹ️", AppRoute.About),
        // Problems outside a game (or with the one running behind the library). In-game reports
        // start from the pause menu, where the scene can be captured.
        DrawerItem("bugreport.menu.title", "⚑",
            onAction = { com.armsx2.ui.bugreport.BugReportFlow.openGeneral(context); onDismiss() }),
    )
    // Exit gets its own trailing section. It was briefly filed under ABOUT, next to the Discord and
    // GitHub links, where nobody would think to look for "quit".
    val session = listOf(
        DrawerItem("games.toolbar.exit", "⏻", iconRes = com.armsx2.R.drawable.ic_power,
            iconTint = ExitRed, onAction = { exitConfirm.value = true }),
    )

    val sections = listOf(
        str("games.section.library") to primary,
        str("ra.options.header") to managers,
        str("about.section.header") to about,
        str("games.section.app") to session,
    )

    Column(
        Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Bottom + WindowInsetsSides.Horizontal)),
    ) {
        // Alça + cabeçalho
        Box(Modifier.fillMaxWidth().padding(top = 10.dp), contentAlignment = Alignment.Center) {
            Box(
                Modifier.width(44.dp).height(5.dp)
                    .background(MaterialTheme.colorScheme.outline, RoundedCornerShape(50)),
            )
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            ArmsLogo(Modifier.weight(1f))
            StatusChip(if (MainActivityRuntime.nativeReady.value) str("backend.driver.active") else str("memcard.status.coreStarting"))
        }
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 108.dp),
            modifier = Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            sections.forEachIndexed { sIndex, (title, list) ->
                item(span = { GridItemSpan(maxLineSpan) }, key = "hdr-$sIndex") {
                    Text(
                        title.uppercase(),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary,
                        letterSpacing = 1.6.sp,
                        modifier = Modifier.padding(start = 4.dp, top = if (sIndex == 0) 4.dp else 14.dp, bottom = 2.dp),
                    )
                }
                items(list, key = { it.titleKey }) { item ->
                    HubTile(
                        controllerId = "hub.${item.titleKey}",
                        title = str(item.titleKey),
                        glyph = item.glyph,
                        iconRes = item.iconRes,
                        iconTint = item.iconTint,
                        glyphIcon = item.glyphIcon,
                        friendsBadge = item.friendsBadge,
                        selected = item.destination != null && sameDestination(selected, item.destination),
                        onClick = { item.onAction?.invoke() ?: item.destination?.let(onNavigate) },
                    )
                }
            }
        }
    }
}

@Composable
private fun HubTile(
    controllerId: String,
    title: String,
    glyph: String,
    iconRes: Int? = null,
    iconTint: Color? = null,
    glyphIcon: Int? = null,
    friendsBadge: Boolean = false,
    selected: Boolean,
    onClick: () -> Unit,
) {
    val shape = RoundedCornerShape(22.dp)
    val contentColor = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
    Surface(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().height(104.dp)
            .controllerFocusable(controllerId, shape, onConfirm = onClick),
        shape = shape,
        color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = if (selected) 0.9f else 0.35f)),
    ) {
        Column(
            Modifier.fillMaxSize().padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Box(Modifier.height(34.dp), contentAlignment = Alignment.Center) {
                when {
                    glyphIcon != null -> com.armsx2.ui.common.GlyphSizedImage(glyph, 26.sp, painterResource(glyphIcon), FontWeight.Bold)
                    iconRes != null -> Icon(painterResource(iconRes), contentDescription = null, tint = iconTint ?: contentColor, modifier = Modifier.size(28.dp))
                    friendsBadge -> Box {
                        Text(glyph, color = contentColor, fontSize = 26.sp)
                        com.armsx2.ui.friends.FriendsCountBadge(Modifier.align(Alignment.TopEnd).offset(x = 8.dp, y = (-6).dp))
                    }
                    else -> Text(glyph, color = contentColor, fontSize = 26.sp)
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                title,
                color = contentColor,
                style = MaterialTheme.typography.labelLarge,
                textAlign = TextAlign.Center,
                maxLines = 2,
            )
        }
    }
}

private fun sameDestination(current: AppRoute, target: AppRoute): Boolean = when (target) {
    AppRoute.Home -> current is AppRoute.Home
    is AppRoute.Settings -> current is AppRoute.Settings
    is AppRoute.BiosManager -> current is AppRoute.BiosManager
    is AppRoute.MemoryCardManager -> current is AppRoute.MemoryCardManager
    is AppRoute.SaveManager -> current is AppRoute.SaveManager
    AppRoute.ControllerManager -> current is AppRoute.ControllerManager
    AppRoute.PatchManager -> current is AppRoute.PatchManager
    AppRoute.TextureManager -> current is AppRoute.TextureManager
    AppRoute.Arcade -> current is AppRoute.Arcade
    AppRoute.Achievements -> current is AppRoute.Achievements
    AppRoute.Language -> current is AppRoute.Language
    AppRoute.News -> current is AppRoute.News
    AppRoute.Friends -> current is AppRoute.Friends
    AppRoute.RemotePlay -> current is AppRoute.RemotePlay
    AppRoute.About -> current is AppRoute.About
}
