package com.armsx2.ui.patches

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import com.armsx2.ui.theme.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.armsx2.GameInfo
import com.armsx2.PatchRepo
import com.armsx2.i18n.str
import com.armsx2.ui.common.ArmsBackdrop
import com.armsx2.ui.common.ArmsTopBar
import com.armsx2.ui.common.GlassPanel
import com.armsx2.ui.common.RoundAction
import com.armsx2.ui.common.SectionTitle
import com.armsx2.ui.common.SettingSwitchRow
import com.armsx2.ui.common.StatusChip
import com.armsx2.ui.settings.controllerFocusable
import java.io.File

@Composable
fun PatchManagerScreen(onBack: () -> Unit, game: GameInfo? = null, viewModel: PatchManagerViewModel = viewModel()) {
    val state = viewModel.state.value
    // ★ Stop any online scan when this leaves the screen.
    //
    // The scan downloads and regex-scans four multi-megabyte repository trees. Left running it
    // competes with the emulator for CPU, which on a low-end device costs full speed and heats
    // the phone badly — reported on a Helio G99, where returning to the game did not stop it.
    // The ViewModel is Activity-scoped and shared with the settings tab, so it does NOT clear
    // just because the user navigated away; this is what actually ends the work.
    androidx.compose.runtime.DisposableEffect(Unit) {
        onDispose { viewModel.cancelOnlineSearch() }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let(viewModel::import) }
    // Folder import: cheats arrive as a folder of files far more often than one at a time, and the
    // single-file picker made adding a set a repetitive chore. Requested by Fun (SD712).
    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        uri?.let(viewModel::importFolder)
    }
    // Keyed on the game (this screen shares one Activity-scoped VM with the settings tab), and
    // resets the online browser first so a previous game's fetched results don't linger here.
    LaunchedEffect(game?.uri) { viewModel.resetOnlineForGame(); viewModel.refresh() }
    // Options on the left, files on the right: the controller keeps to a column and crosses with
    // Left/Right.
    com.armsx2.ui.settings.ColumnControllerNav()

    ArmsBackdrop {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            ArmsTopBar(
                title = str("patches.dialog.patchesAndCheats"),
                // Reachable by the controller, so Up from the first control comes back to the top of
                // the screen; with nothing above that control, the page could not scroll back to it.
                leading = { RoundAction("←", str("action.back"), onBack, controllerId = "patches.top.back") },
                actions = {
                    RoundAction("＋", str("action.import"), { picker.launch(arrayOf("text/plain", "application/octet-stream", "*/*")) }, controllerId = "patches.top.import")
                    RoundAction("🗀", str("patches.import.folder"), { folderPicker.launch(null) }, controllerId = "patches.top.folder")
                    RoundAction("✎", str("patches.editor.new"), viewModel::newEditor, controllerId = "patches.top.new")
                    RoundAction("↻", str("games.card.refresh"), viewModel::refresh, controllerId = "patches.top.refresh")
                },
            )
            PatchDisclaimer()
            OnlineBrowser(state, viewModel, game, Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp))
            BoxWithConstraints(Modifier.fillMaxWidth()) {
                val compact = maxWidth < 820.dp
                if (compact) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
                        PatchOptions(state, viewModel, Modifier.fillMaxWidth())
                        Spacer(Modifier.padding(top = 10.dp))
                        PatchFiles(state, viewModel, Modifier.fillMaxWidth())
                    }
                } else {
                    Row(
                        Modifier.fillMaxWidth().padding(start = 8.dp, end = 8.dp, bottom = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        PatchOptions(state, viewModel, Modifier.width(310.dp))
                        PatchFiles(state, viewModel, Modifier.weight(1f))
                    }
                }
            }
        }
    }
    if (state.editorPath != null) {
        PnachEditor(state, viewModel)
    }
    (state.error ?: state.message)?.let { message ->
        androidx.compose.runtime.DisposableEffect(Unit) {
            com.armsx2.MenuSfx.play(com.armsx2.MenuSfx.Event.POPUP_OPEN)
            onDispose { com.armsx2.MenuSfx.play(com.armsx2.MenuSfx.Event.POPUP_CLOSE) }
        }
        com.armsx2.ui.common.NotifyOverlay(
            title = if (state.error == null) str("action.ok") else str("patches.dialog.patchesAndCheats"),
            message = message,
            onDismiss = viewModel::dismissMessage,
            idPrefix = "patches.message",
        )
    }
}

/**
 * Raw .pnach text editor.
 *
 * A plain text buffer, not a structured code form: pnach is what people copy off the web, headers
 * and comments included, so anything that re-serialised it would mangle the paste.
 *
 * The explicit Paste button matters more than it looks — on a handheld with no touchscreen there is
 * no way to reach the long-press paste menu, which is most of why "paste a code you found" didn't
 * work here before.
 */
@Composable
private fun PnachEditor(state: PatchManagerUiState, viewModel: PatchManagerViewModel) {
    val clipboard = androidx.compose.ui.platform.LocalClipboardManager.current
    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.scrim.copy(alpha = 0.72f)),
    ) {
        Surface(
            Modifier.fillMaxSize().padding(10.dp),
            shape = RoundedCornerShape(18.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
        ) {
            Column(Modifier.fillMaxSize().padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        state.editorName.ifBlank { str("patches.editor.new") },
                        style = MaterialTheme.typography.titleSmall,
                        modifier = Modifier.weight(1f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    val paste = {
                        clipboard.getText()?.text?.let { pasted ->
                            // Append rather than replace: the buffer already holds a gametitle line
                            // (new file) or the user's existing codes (edit), and clobbering either
                            // is never what "paste" is meant to do.
                            viewModel.updateEditorText(
                                if (state.editorText.isEmpty()) pasted
                                else state.editorText.trimEnd() + "\n" + pasted,
                            )
                        }
                        Unit
                    }
                    TextButton(
                        onClick = paste,
                        modifier = Modifier.controllerFocusable("patches.editor.paste", onConfirm = paste),
                    ) { Text(str("patches.editor.paste")) }
                    TextButton(
                        onClick = viewModel::closeEditor,
                        modifier = Modifier.controllerFocusable("patches.editor.cancel", onConfirm = viewModel::closeEditor),
                    ) { Text(str("action.cancel")) }
                    TextButton(
                        onClick = viewModel::saveEditor,
                        enabled = !state.editorLoading,
                        modifier = Modifier.controllerFocusable("patches.editor.save", onConfirm = viewModel::saveEditor),
                    ) { Text(str("action.save")) }
                }
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(
                    value = state.editorText,
                    onValueChange = viewModel::updateEditorText,
                    modifier = Modifier.fillMaxSize(),
                    textStyle = MaterialTheme.typography.bodySmall.copy(
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                    ),
                    placeholder = { Text(str("patches.editor.placeholder")) },
                )
            }
        }
    }
}

// Outdated cheats/patches (built for the old 1.7 core) are our #1 cause of false "it broke
// in the new version" reports — this warning sits on both patch-screen entry points.
@Composable
private fun PatchDisclaimer() {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)),
    ) {
        Row(
            Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.Top,
        ) {
            Text("⚠", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            Text(str("patches.disclaimer"), style = MaterialTheme.typography.bodySmall)
        }
    }
}

/**
 * Cheats/patches as a Settings-hub tab — lets users manage PNACH cheats outside a game.
 * Reuses the full PatchManager stack (per-cheat toggles + online browser); it just drops
 * the screen chrome (ArmsBackdrop / ArmsTopBar / own scroll) since the settings hub
 * already supplies those, and re-surfaces Import/Refresh as an inline action row.
 */
@Composable
fun PatchesSettingsTab(game: GameInfo? = null, viewModel: PatchManagerViewModel = viewModel()) {
    val state = viewModel.state.value
    // ★ Stop any online scan when this leaves the screen.
    //
    // The scan downloads and regex-scans four multi-megabyte repository trees. Left running it
    // competes with the emulator for CPU, which on a low-end device costs full speed and heats
    // the phone badly — reported on a Helio G99, where returning to the game did not stop it.
    // The ViewModel is Activity-scoped and shared with the settings tab, so it does NOT clear
    // just because the user navigated away; this is what actually ends the work.
    androidx.compose.runtime.DisposableEffect(Unit) {
        onDispose { viewModel.cancelOnlineSearch() }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let(viewModel::import) }
    // Keyed on the game, not Unit: the scope switch above hands this tab a different game
    // (the game, or null for Global), and refresh() is what re-reads the tier. Keyed on
    // Unit it read once and then showed the wrong tier's values for the rest of the visit.
    // resetOnlineForGame() first, so a previous game's fetched cheats/patches don't linger in
    // this game's browser (the fetch is manual, so nothing else clears them).
    LaunchedEffect(game?.uri) { viewModel.resetOnlineForGame(); viewModel.refresh() }

    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            RoundAction("＋", str("action.import"), { picker.launch(arrayOf("text/plain", "application/octet-stream", "*/*")) })
            RoundAction("↻", str("games.card.refresh"), viewModel::refresh)
        }
        PatchDisclaimer()
        OnlineBrowser(state, viewModel, game, Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp))
        BoxWithConstraints(Modifier.fillMaxWidth()) {
            val compact = maxWidth < 820.dp
            if (compact) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
                    PatchOptions(state, viewModel, Modifier.fillMaxWidth())
                    Spacer(Modifier.padding(top = 10.dp))
                    PatchFiles(state, viewModel, Modifier.fillMaxWidth())
                }
            } else {
                Row(
                    Modifier.fillMaxWidth().padding(start = 8.dp, end = 8.dp, bottom = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    PatchOptions(state, viewModel, Modifier.width(310.dp))
                    PatchFiles(state, viewModel, Modifier.weight(1f))
                }
            }
        }
    }
    (state.error ?: state.message)?.let { message ->
        androidx.compose.runtime.DisposableEffect(Unit) {
            com.armsx2.MenuSfx.play(com.armsx2.MenuSfx.Event.POPUP_OPEN)
            onDispose { com.armsx2.MenuSfx.play(com.armsx2.MenuSfx.Event.POPUP_CLOSE) }
        }
        com.armsx2.ui.common.NotifyOverlay(
            title = if (state.error == null) str("action.ok") else str("patches.dialog.patchesAndCheats"),
            message = message,
            onDismiss = viewModel::dismissMessage,
            idPrefix = "patches.message",
        )
    }
}

@Composable
private fun PatchOptions(state: PatchManagerUiState, viewModel: PatchManagerViewModel, modifier: Modifier) {
    GlassPanel(modifier) {
        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            SectionTitle(str("ra.options.header"), str("scope.global"))
            SettingSwitchRow(
                str("patches.cheats.label"), str("patches.pasteImportHint"), state.settings.emuCore.enableCheats,
                onCheckedChange = { value -> viewModel.update { it.copy(emuCore = it.emuCore.copy(enableCheats = value)) } },
                modifier = Modifier.controllerFocusable(
                    "patches.enableCheats",
                    onConfirm = { viewModel.update { it.copy(emuCore = it.emuCore.copy(enableCheats = !state.settings.emuCore.enableCheats)) } },
                ),
            )
            SettingSwitchRow(
                // Own description rather than the shared "applies at boot" line: this one silently
                // auto-applies a patch to every game that has one, which reads nothing like
                // "enable widescreen patches" and cost a long GT4 rendering hunt to track down.
                str("patches.widescreen.label"), str("patches.widescreen.description"), state.settings.emuCore.enableWideScreenPatches,
                onCheckedChange = { value -> viewModel.update { it.copy(emuCore = it.emuCore.copy(enableWideScreenPatches = value)) } },
                modifier = Modifier.controllerFocusable(
                    "patches.widescreen",
                    onConfirm = { viewModel.update { it.copy(emuCore = it.emuCore.copy(enableWideScreenPatches = !state.settings.emuCore.enableWideScreenPatches)) } },
                ),
            )
            SettingSwitchRow(
                str("patches.noInterlacing.label"), str("patches.applyAtBoot"), state.settings.emuCore.enableNoInterlacingPatches,
                onCheckedChange = { value -> viewModel.update { it.copy(emuCore = it.emuCore.copy(enableNoInterlacingPatches = value)) } },
                modifier = Modifier.controllerFocusable(
                    "patches.noInterlacing",
                    onConfirm = { viewModel.update { it.copy(emuCore = it.emuCore.copy(enableNoInterlacingPatches = !state.settings.emuCore.enableNoInterlacingPatches)) } },
                ),
            )
            // HostFS (host: filesystem) — lets ELF/homebrew and certain advanced mods read
            // from the host. Native field + apply already exist; this restores the toggle.
            SettingSwitchRow(
                str("patches.hostFs.label"), str("patches.hostFs.description"), state.settings.emuCore.hostFs,
                onCheckedChange = { value -> viewModel.update { it.copy(emuCore = it.emuCore.copy(hostFs = value)) } },
                modifier = Modifier.controllerFocusable(
                    "patches.hostFs",
                    onConfirm = { viewModel.update { it.copy(emuCore = it.emuCore.copy(hostFs = !state.settings.emuCore.hostFs)) } },
                ),
            )
            // Where host: actually reads from. Worth stating outright: on Android the root
            // CANNOT be the folder holding the disc, because a SAF content:// URI has no
            // parent directory to derive one from (see Hle_SetHostRoot). Without this line
            // the natural assumption is "next to the ISO", which silently reads nothing.
            if (state.settings.emuCore.hostFs) {
                Text(
                    str("patches.hostFs.folder"),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 10.dp),
                )
            }
        }
    }
}

@Composable
private fun OnlineBrowser(
    state: PatchManagerUiState,
    viewModel: PatchManagerViewModel,
    game: GameInfo?,
    modifier: Modifier,
) {
    GlassPanel(modifier) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SectionTitle(str("patches.online.header"), game?.title ?: str("scope.game"))
            // Hard game guard: online results belong to the game they were fetched for. The whole
            // patch UI shares one Activity-scoped VM, so a previous game's results must never
            // render in another game's tab (the reported "GT4 shows GTA:SA's cheats").
            val forThisGame = state.onlineForGameKey == (game?.uri?.toString() ?: "")
            val entries = if (forThisGame) state.onlineEntries else emptyList()
            val searching = state.onlineLoading && forThisGame
            val largeSearching = state.largeLoading && forThisGame
            when {
                // Says how long, and that leaving is safe. On a slow connection the file lists
                // take a while, and users reported assuming it had hung. The second line matters as
                // much as the first: the search now stops when this screen closes, so nobody has
                // to sit and wait to protect their device.
                searching && entries.isEmpty() -> Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(10.dp))
                        Text(str("patches.online.loading"))
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        str("patches.online.loading.hint"),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                entries.isEmpty() -> Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { viewModel.fetchOnline(game) },
                        modifier = Modifier.controllerFocusable("patches.online.fetch", onConfirm = { viewModel.fetchOnline(game) }),
                    ) {
                        Text(str("patches.online.fetch"))
                    }
                    LargeCheatSearch(largeSearching) { viewModel.fetchLargeCheats(game) }
                }
                else -> {
                    if (state.onlineTitle.isNotBlank()) {
                        Text(state.onlineTitle, style = MaterialTheme.typography.titleSmall)
                    }
                    // Install/Refresh sit ABOVE the lists. They used to render after both sections,
                    // so with a large cheat list (54 for GoW2, often far more) the Install button
                    // was pushed off the bottom of the screen: users ticked a patch, found no way
                    // to apply it, and backed out — and the tick is only a transient selection, so
                    // nothing was ever installed and the tick was gone on return. Pinned above the
                    // lists, the action stays reachable no matter how long they get.
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Button(
                            onClick = viewModel::installSelected,
                            enabled = state.onlineSelected.isNotEmpty(),
                            modifier = Modifier.controllerFocusable("patches.online.install", onConfirm = { if (state.onlineSelected.isNotEmpty()) viewModel.installSelected() }),
                        ) {
                            Text("${str("patches.online.install")} (${state.onlineSelected.size})")
                        }
                        TextButton(
                            onClick = { viewModel.fetchOnline(game) },
                            modifier = Modifier.controllerFocusable("patches.online.refresh", onConfirm = { viewModel.fetchOnline(game) }),
                        ) { Text(str("games.card.refresh")) }
                    }
                    // The patches the app ships are already listed; the online sources are still on
                    // their way. The large database waits until they are in, since this search
                    // replaces the list when it finishes.
                    if (searching) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(10.dp))
                            Text(str("patches.online.loading"), style = MaterialTheme.typography.bodySmall)
                        }
                    } else {
                        LargeCheatSearch(largeSearching) { viewModel.fetchLargeCheats(game) }
                    }
                    // Patches and cheats each get their own collapsible section. Patches (few — the
                    // whole point of searching) expand by default; cheats (often thousands) collapse
                    // by default, which kills BOTH the endless scroll AND the lag: a collapsed
                    // section doesn't compose its rows, and each row otherwise registers a
                    // controller-nav entry. Expand cheats deliberately when you actually want them.
                    val patches = entries.filter { it.source == "patches" }
                    val cheats = entries.filter { it.source != "patches" }
                    if (patches.isNotEmpty()) {
                        CollapsibleOnlineSection("${str("patches.section.patches")} (${patches.size})", initiallyExpanded = true) {
                            patches.forEach { entry ->
                                OnlineEntryRow(entry, entry.name in state.onlineSelected) { viewModel.toggleOnline(entry.name) }
                            }
                        }
                    }
                    if (cheats.isNotEmpty()) {
                        CollapsibleOnlineSection("${str("patches.section.cheats")} (${cheats.size})", initiallyExpanded = false) {
                            cheats.forEach { entry ->
                                OnlineEntryRow(entry, entry.name in state.onlineSelected) { viewModel.toggleOnline(entry.name) }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * The large cheat database's own button: kept apart from the regular search the way ARMSX3 keeps
 * Artemis apart from the RPCS3 patches, because its file list alone outweighs everything else the
 * search downloads. A spinner while it runs.
 */
@Composable
private fun LargeCheatSearch(searching: Boolean, onSearch: () -> Unit) {
    if (searching) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
            Spacer(Modifier.width(10.dp))
            Text(str("patches.online.large.loading"), style = MaterialTheme.typography.bodySmall)
        }
        return
    }
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        OutlinedButton(
            onClick = onSearch,
            modifier = Modifier.controllerFocusable("patches.online.large", onConfirm = onSearch),
        ) {
            Text(str("patches.online.large"))
        }
        Text(
            str("patches.online.large.hint"),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun OnlineEntryRow(entry: PatchRepo.Entry, checked: Boolean, onToggle: () -> Unit) {
    Surface(
        onClick = onToggle,
        // Confirm (A) only — same reason as LocalCheatRow: scrolling past an entry must not tick
        // it for install.
        modifier = Modifier.fillMaxWidth().controllerFocusable(
            "patches.online.entry.${entry.name}",
            RoundedCornerShape(14.dp),
            onConfirm = onToggle,
        ),
        shape = RoundedCornerShape(14.dp),
        color = if (checked) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
        border = BorderStroke(
            1.dp,
            if (checked) MaterialTheme.colorScheme.primary.copy(alpha = 0.5f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.42f),
        ),
    ) {
        Row(Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = checked, onCheckedChange = { onToggle() })
            Spacer(Modifier.width(6.dp))
            Column(Modifier.weight(1f)) {
                Text(entry.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (entry.description.isNotBlank()) {
                    Text(entry.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
            }
            Spacer(Modifier.width(8.dp))
            StatusChip(entry.source)
        }
    }
}

/** A real collapsible section for the online browser (the shared CollapsibleSection widget is
 *  header-only — it always composes its content). Only composes [content] when expanded, so a
 *  collapsed cheats list of thousands neither draws nor registers its per-row controller-nav
 *  entries — that's what makes the giant list cheap until you deliberately open it. */
@Composable
private fun CollapsibleOnlineSection(
    title: String,
    initiallyExpanded: Boolean,
    content: @Composable () -> Unit,
) {
    var expanded by remember { mutableStateOf(initiallyExpanded) }
    Surface(
        onClick = { expanded = !expanded },
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
        modifier = Modifier.fillMaxWidth().controllerFocusable(
            "patches.online.section.$title", RoundedCornerShape(12.dp), onConfirm = { expanded = !expanded },
        ),
    ) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (expanded) "▾" else "▸",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary,
            )
            Spacer(Modifier.width(10.dp))
            Text(title, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
        }
    }
    if (expanded) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { content() }
    }
}

@Composable
private fun PatchFiles(state: PatchManagerUiState, viewModel: PatchManagerViewModel, modifier: Modifier) {
    // The whole installed list folds away. A pnach pulled from the downloader can carry hundreds of
    // codes, and with the list open there was no way past it to the rest of the screen.
    var listOpen by androidx.compose.runtime.saveable.rememberSaveable { mutableStateOf(true) }
    Column(modifier) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { listOpen = !listOpen },
            verticalAlignment = Alignment.CenterVertically,
        ) {
            SectionTitle(
                str("patches.installedHeader"),
                state.files.size.toString(),
                Modifier.weight(1f),
            )
            if (state.files.isNotEmpty()) {
                Text(
                    if (listOpen) "▾" else "▸",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(horizontal = 8.dp),
                )
            }
        }
        if (state.bundledEntry.isNotBlank()) {
            BundledPatchCard(
                entry = state.bundledEntry,
                cheats = state.bundledCheats,
                unlabelled = state.bundledUnlabelled,
                onExtract = viewModel::extractBundled,
            )
            Spacer(Modifier.height(8.dp))
        }
        if (state.files.isEmpty()) {
            PatchFilesEmptyState()
        } else if (listOpen) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                state.files.forEach { file ->
                    val expanded = state.localExpandedPath == file.absolutePath
                    PatchFileRow(
                        file = file,
                        expanded = expanded,
                        cheats = if (expanded) state.localCheats else emptyList(),
                        onExpand = { viewModel.expandLocal(file) },
                        onToggleCheat = viewModel::toggleLocalCheat,
                        onSetAllCheats = viewModel::setAllLocalCheats,
                        onEdit = { viewModel.openEditor(file) },
                        onDelete = { viewModel.delete(file) },
                    )
                }
            }
        }
    }
}

/**
 * What ARMSX2's own patches.zip is doing to this game.
 *
 * Exists because that was previously invisible: the OSD would say "3 game patches are active" and
 * the manager showed an empty list, because it only knows about files on disk. Reported by Rei
 * Ayanami, who correctly concluded there was nothing to find.
 */
@Composable
private fun BundledPatchCard(
    entry: String,
    cheats: List<PatchRepo.LocalCheat>,
    unlabelled: Int,
    onExtract: () -> Unit,
) {
    Surface(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.46f)),
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                str("patches.bundled.header"),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
            )
            Text(
                str("patches.bundled.explain"),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(entry, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            cheats.forEach { cheat ->
                val unnamed = cheat.name.equals("Unlabelled", true)
                Text(
                    if (unnamed) "• ${cheat.name} (${str("patches.bundled.alwaysOn")})" else "• ${cheat.name}",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (unnamed) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurface,
                )
            }
            TextButton(
                onClick = onExtract,
                modifier = Modifier.controllerFocusable("patches.bundled.extract", onConfirm = onExtract),
            ) { Text(str("patches.bundled.extract")) }
        }
    }
}

@Composable
private fun PatchFilesEmptyState() {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.42f)),
        tonalElevation = 1.dp,
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 18.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.primaryContainer,
            ) {
                BoxWithConstraints(
                    modifier = Modifier.size(48.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = "✦",
                        style = MaterialTheme.typography.headlineSmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                    )
                }
            }
            Column(Modifier.weight(1f)) {
                Text(
                    text = str("patches.noFilesInstalled"),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = str("patches.pasteImportHint"),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun PatchFileRow(
    file: File,
    expanded: Boolean,
    cheats: List<PatchRepo.LocalCheat>,
    onExpand: () -> Unit,
    onToggleCheat: (String) -> Unit,
    onSetAllCheats: (Boolean) -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
) {
    Surface(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.46f)),
    ) {
        Column {
            Row(
                Modifier.fillMaxWidth().clickable(onClick = onExpand).controllerFocusable("patches.file.${file.absolutePath}", onConfirm = onExpand).padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(if (expanded) "▾" else "▸", color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(file.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(file.parentFile?.name.orEmpty(), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                TextButton(onClick = onEdit, modifier = Modifier.controllerFocusable("patches.file.${file.absolutePath}.edit", onConfirm = onEdit)) { Text(str("action.edit")) }
                TextButton(onClick = onDelete, modifier = Modifier.controllerFocusable("patches.file.${file.absolutePath}.delete", onConfirm = onDelete)) { Text(str("action.delete")) }
            }
            if (expanded) {
                if (cheats.isEmpty()) {
                    Text(
                        str("patches.local.noCheats"),
                        Modifier.padding(start = 42.dp, end = 14.dp, bottom = 12.dp),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else {
                    Column(Modifier.padding(start = 34.dp, end = 12.dp, bottom = 8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        // Above the list, not below it: a community pnach can run to a hundred
                        // entries, and a control you have to scroll past all of them to reach is
                        // no better than flipping them one at a time.
                        if (cheats.size > 1) {
                            Row(
                                Modifier.fillMaxWidth().padding(bottom = 4.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                val anyOff = cheats.any { !it.enabled }
                                val anyOn = cheats.any { it.enabled }
                                TextButton(
                                    onClick = { onSetAllCheats(true) },
                                    enabled = anyOff,
                                    modifier = Modifier.controllerFocusable(
                                        "patches.allOn.${file.absolutePath}",
                                        onConfirm = { if (anyOff) onSetAllCheats(true) },
                                    ),
                                ) { Text(str("patches.action.allOn")) }
                                TextButton(
                                    onClick = { onSetAllCheats(false) },
                                    enabled = anyOn,
                                    modifier = Modifier.controllerFocusable(
                                        "patches.allOff.${file.absolutePath}",
                                        onConfirm = { if (anyOn) onSetAllCheats(false) },
                                    ),
                                ) { Text(str("patches.action.allOff")) }
                            }
                        }
                        cheats.forEach { cheat -> LocalCheatRow(cheat) { onToggleCheat(cheat.name) } }
                    }
                }
            }
        }
    }
}

@Composable
private fun LocalCheatRow(cheat: PatchRepo.LocalCheat, onToggle: () -> Unit) {
    Row(
        // Confirm (A) only — no onLeft/onRight. D-pad Right used to enable the cheat under the
        // cursor, so simply scrolling down a cheat list armed everything you passed. Enabling a
        // patch or cheat must always be a deliberate press.
        Modifier.fillMaxWidth().clickable(onClick = onToggle).controllerFocusable(
            "patches.cheat.${cheat.name}",
            onConfirm = onToggle,
        ).padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(cheat.name, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (cheat.description.isNotBlank()) {
                Text(cheat.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
        Spacer(Modifier.width(8.dp))
        Switch(checked = cheat.enabled, onCheckedChange = { onToggle() })
    }
}
