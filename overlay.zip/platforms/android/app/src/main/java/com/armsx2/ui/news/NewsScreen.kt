package com.armsx2.ui.news

import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.layout.findRootCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import com.armsx2.ui.theme.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.armsx2.News
import com.armsx2.i18n.str
import com.armsx2.ui.common.ArmsBackdrop
import com.armsx2.ui.common.ArmsTopBar
import com.armsx2.ui.common.GlassPanel
import com.armsx2.ui.common.RoundAction
import com.armsx2.ui.settings.SettingsControllerNav
import com.armsx2.ui.settings.controllerFocusable

/**
 * Release notes, newest first.
 *
 * A plain Column rather than a LazyColumn on purpose: controllerFocusable only registers items that
 * are actually composed, so a lazy list hands the pad a nav registry with holes in it. Twenty
 * releases of text is nothing to measure.
 */
@Composable
fun NewsScreen(onBack: () -> Unit, viewModel: NewsViewModel = viewModel()) {
    val state = viewModel.state.value
    LaunchedEffect(Unit) { viewModel.load() }

    ArmsBackdrop {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            ArmsTopBar(
                title = str("news.title"),
                leading = { RoundAction("←", str("action.back"), onBack, controllerId = "news.back") },
                actions = {
                    // Named, not a trailing lambda: RoundAction's last parameter is glyphColor, so
                    // a trailing lambda binds there rather than to onClick.
                    RoundAction("⟳", str("news.refresh"), onClick = { viewModel.load(force = true) }, controllerId = "news.refresh")
                },
            )

            Column(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                when {
                    state.loading && state.items.isEmpty() -> GlassPanel(Modifier.fillMaxWidth()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.size(10.dp))
                            Text(str("news.loading"), style = MaterialTheme.typography.bodySmall)
                        }
                    }

                    state.items.isEmpty() -> GlassPanel(Modifier.fillMaxWidth()) {
                        Text(str("news.unavailable"), style = MaterialTheme.typography.bodySmall)
                    }

                    else -> {
                        // Say so rather than presenting stale notes as live — same rule the texture
                        // catalogue follows when its mirrors are unreachable.
                        if (state.fromCache) {
                            GlassPanel(Modifier.fillMaxWidth()) {
                                Text(str("news.offline"), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        // Newest open, the rest collapsed: the page should be scannable, not a wall
                        // of every changelog we have ever shipped.
                        state.items.forEachIndexed { index, item ->
                            ReleaseCard(item, initiallyExpanded = index == 0)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}

/**
 * The people this release credits, with their pictures.
 *
 * Read straight out of the release notes' @mentions, so it says exactly who the notes thank —
 * including contributors whose work was ported in under somebody else's commit.
 */
@Composable
private fun ReleaseContributors(people: List<News.Contributor>) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(
            str("news.contributors"),
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            people.forEach { person ->
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.size(width = 56.dp, height = 62.dp),
                ) {
                    AsyncImage(
                        model = person.avatar,
                        contentDescription = person.login,
                        modifier = Modifier.size(34.dp).clip(CircleShape),
                        contentScale = ContentScale.Crop,
                    )
                    Spacer(Modifier.height(3.dp))
                    Text(
                        person.login,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                    )
                }
            }
        }
    }
}

/**
 * A picture from the release notes, fetched once it comes within a screen of the viewport: an opened
 * card lays out every picture at once, and a release can carry dozens of full-size screenshots. Until
 * then the space is held at the picture's shape.
 */
@Composable
private fun NotePicture(image: News.Block.Image, modifier: Modifier = Modifier) {
    var near by remember(image.url) { mutableStateOf(false) }

    Box(
        modifier
            .fillMaxWidth()
            .aspectRatio(image.aspectRatio)
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
            .onGloballyPositioned { coordinates ->
                if (!near) {
                    val windowHeight = coordinates.findRootCoordinates().size.height
                    near = coordinates.positionInWindow().y < windowHeight * 2f
                }
            },
    ) {
        if (near) {
            AsyncImage(
                model = image.url,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Fit,
            )
        }
    }
}

@Composable
private fun ReleaseCard(item: News.Item, initiallyExpanded: Boolean) {
    // Keyed on the tag so it survives rotation.
    var expanded by rememberSaveable(item.tag) { mutableStateOf(initiallyExpanded) }
    val toggle = { expanded = !expanded }

    // The pad's outline goes on the panel, in its shape, so it traces the card's edge
    GlassPanel(
        Modifier
            .fillMaxWidth()
            .controllerFocusable("news.${item.tag}", shape = RoundedCornerShape(28.dp), onConfirm = toggle),
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                // clickable as well as the pad stop above, which only wires the pad's confirm
                // button into the nav registry and does not make anything respond to a finger
                .clickable(onClick = toggle),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (item.authorAvatar.isNotBlank()) {
                    AsyncImage(
                        model = item.authorAvatar,
                        contentDescription = item.authorLogin,
                        modifier = Modifier.size(32.dp).clip(CircleShape),
                        contentScale = ContentScale.Crop,
                    )
                    Spacer(Modifier.size(10.dp))
                }
                Column(Modifier.weight(1f).padding(end = 8.dp)) {
                    Text(
                        item.title,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Text(
                        buildString {
                            append(item.tag)
                            if (item.published.isNotBlank()) append(" · ").append(item.published)
                            if (item.authorLogin.isNotBlank()) append(" · ").append(item.authorLogin)
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                if (item.prerelease) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = MaterialTheme.colorScheme.secondaryContainer,
                    ) {
                        Text(
                            str("news.prerelease"),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        )
                    }
                }
            }

            // Under the notes, above nothing else: the credit belongs with the release it is for.
            if (expanded && item.credited.isNotEmpty()) {
                ReleaseContributors(item.credited)
            }

            if (item.blocks.isEmpty()) {
                Text(str("news.noNotes"), style = MaterialTheme.typography.bodySmall)
            } else {
                if (expanded) {
                    // A pad stop per paragraph and picture, so Down reads through a long release
                    // instead of jumping past it
                    var stop = 0
                    // Closing from inside takes the paragraph's stop away; the selection goes to the
                    // card rather than falling back to the top of the screen
                    val collapse = {
                        expanded = false
                        SettingsControllerNav.selectById("news.${item.tag}")
                        Unit
                    }
                    item.blocks.forEach { block ->
                        when (block) {
                            is News.Block.Text -> block.text.split("\n\n").forEach { paragraph ->
                                Text(
                                    paragraph,
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.controllerFocusable("news.${item.tag}.${stop++}", onConfirm = collapse, ring = false),
                                )
                            }
                            is News.Block.Image -> NotePicture(
                                block,
                                Modifier.controllerFocusable("news.${item.tag}.${stop++}", onConfirm = collapse, ring = false),
                            )
                        }
                    }
                } else {
                    // The preview stays text: pictures only load once the card is opened
                    Text(
                        item.notes,
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 6,
                    )
                }
                Text(
                    str(if (expanded) "news.showLess" else "news.showMore"),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    // Padded so it is a real touch target rather than a line of 11sp text, and
                    // clickable in its own right even though the whole card toggles too — it looks
                    // like a link, so it has to behave like one.
                    modifier = Modifier
                        .clickable(onClick = toggle)
                        .padding(vertical = 4.dp),
                )
            }
        }
    }
}
